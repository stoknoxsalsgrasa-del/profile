module.exports = {
  tokens: "8587039364:AAHvTM7w5cepuFK8D5Yd2iAJsYod6SZZi_w",  // Ubah Jadi Token Bot Mu !!!
  owner: "8562154048", // Ubah Jadi Id Mu !!!
  port: "45000", // Ubah Jadi Port Panel Mu !!!
  ipvps: "151.242.116.40,https://thandz.ziihost.store/server/502696a2/files" // Ubah Jadi Ip Vps Mu !!!
};